# SPDX-License-Identifier: GPL-3.0-or-later
"""Extraction of sanitized, layout-neutral biographical facts."""

from __future__ import annotations

from dataclasses import dataclass

from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.display.place import displayer as place_displayer
from gramps.gen.lib import Date, EventType, PlaceType
from gramps.gen.utils.db import get_birth_or_fallback, get_death_or_fallback
from gramps.gen.utils.location import get_main_location

try:
    from .model import (
        InformationLine,
        InformationProfile,
        PersonView,
        PersonViewSeed,
        VisibilityState,
    )
    from .names import NameFormatter, derive_name_labels
except ImportError:  # Gramps loads add-ons as top-level modules.
    from model import (  # type: ignore[no-redef]
        InformationLine,
        InformationProfile,
        PersonView,
        PersonViewSeed,
        VisibilityState,
    )
    from names import NameFormatter, derive_name_labels  # type: ignore[no-redef]


@dataclass(frozen=True, slots=True)
class VitalFact:
    """One formatted vital date and whether a fallback event supplied it."""

    text: str
    year: int | None
    fallback: bool


@dataclass(frozen=True, slots=True)
class VitalDates:
    """Birth and death facts ready for information profiles."""

    birth: VitalFact
    death: VitalFact


@dataclass(frozen=True, slots=True)
class EventFact:
    """One optional event fact before layout."""

    text: str
    date_text: str
    place: str
    year: int | None


def event_date_symbol(event_type: int, occurrence: int = 1) -> str:
    """Return the genealogical symbol for one event date."""
    if occurrence < 1:
        raise ValueError("event occurrence must be positive")
    if event_type == EventType.BIRTH:
        return "°"
    if event_type == EventType.DEATH:
        return "†"
    if event_type == EventType.MARRIAGE:
        return "⚭" if occurrence == 1 else f"⚭{occurrence}"
    return ""


def _format_years(date) -> str:
    """Format a Gramps date as a year while retaining its uncertainty."""
    year = date.get_year()
    if not year:
        return ""

    modifier = date.get_modifier()
    if modifier in {Date.MOD_BEFORE, Date.MOD_TO}:
        return f"/{year}"
    if modifier in {Date.MOD_AFTER, Date.MOD_FROM}:
        return f"{year}/"
    if modifier == Date.MOD_ABOUT or date.get_quality() & Date.QUAL_ESTIMATED:
        return f"ca {year}"

    if date.is_compound():
        stop = date.get_stop_date()
        stop_year = stop[2] if stop and len(stop) > 2 else 0
        if stop_year and stop_year != year:
            return f"{year}–{stop_year}"
    return str(year)


def format_date(date, date_format: str, locale=glocale) -> str:
    """Format one Gramps Date without changing global locale preferences."""
    if date_format not in {"years", "short", "full"}:
        raise ValueError(f"unsupported date format: {date_format}")
    if date is None or not date.is_valid():
        return ""
    if date_format == "years":
        return _format_years(date)
    displayer = locale.date_displayer
    if hasattr(displayer, "set_format"):
        format_number = 1 if date_format == "short" else 2
        displayer = type(displayer)(format=format_number, blocale=locale)
    return displayer.display_formatted(date)


def format_event_date(
    date,
    date_format: str,
    event_type: int,
    *,
    occurrence: int = 1,
    locale=glocale,
) -> str:
    """Format an event date with its conventional genealogical symbol."""
    text = format_date(date, date_format, locale)
    if not text:
        return ""
    symbol = event_date_symbol(event_type, occurrence)
    return f"{symbol} {text}" if symbol else text


def _event_fact(
    event,
    direct_ref,
    date_format: str,
    locale,
    event_type: int,
    *,
    occurrence: int = 1,
) -> VitalFact:
    if event is None:
        return VitalFact("", None, False)
    date = event.get_date_object()
    text = format_event_date(
        date,
        date_format,
        event_type,
        occurrence=occurrence,
        locale=locale,
    )
    year = date.get_year() if date is not None and date.is_valid() else None
    direct_handle = direct_ref.get_reference_handle() if direct_ref else None
    return VitalFact(text, year or None, event.get_handle() != direct_handle)


def extract_vital_dates(
    database,
    person,
    date_format: str,
    locale=glocale,
) -> VitalDates:
    """Read birth/death events, including Gramps fallback events."""
    if date_format not in {"years", "short", "full"}:
        raise ValueError(f"unsupported date format: {date_format}")
    birth = get_birth_or_fallback(database, person)
    death = get_death_or_fallback(database, person)
    return VitalDates(
        birth=_event_fact(
            birth, person.get_birth_ref(), date_format, locale, EventType.BIRTH
        ),
        death=_event_fact(
            death, person.get_death_ref(), date_format, locale, EventType.DEATH
        ),
    )


def _object_has_tag(value, tag_handle: str, tag_name: str = "Source OK") -> bool:
    """Return whether a Gramps object carries the resolved evidence tag.

    Gramps normally stores tag handles on primary objects. Some database
    adapters expose tag names or lightweight tag objects instead, so accept
    those representations too while retaining an exact-name comparison.
    """
    if value is None:
        return False
    getter = getattr(value, "get_tag_list", None)
    if not callable(getter):
        return False
    try:
        for tag in tuple(getter()):
            if isinstance(tag, str) and tag in {tag_handle, tag_name}:
                return True
            get_handle = getattr(tag, "get_handle", None)
            if callable(get_handle) and get_handle() == tag_handle:
                return True
            get_name = getattr(tag, "get_name", None)
            if callable(get_name) and get_name() == tag_name:
                return True
        return False
    except Exception:
        return False


def _event_has_source_ok_tag(
    database, event, tag_handle: str, tag_name: str = "Source OK"
) -> bool:
    """Check the event and its citation/source chain for the evidence tag."""
    if event is None or not tag_handle:
        return False
    if _object_has_tag(event, tag_handle, tag_name):
        return True
    try:
        references = event.get_citation_ref_list()
    except Exception:
        references = ()
    for reference in references:
        try:
            citation_handle = reference.get_reference_handle()
            citation = database.get_citation_from_handle(citation_handle)
        except Exception:
            continue
        if _object_has_tag(citation, tag_handle, tag_name):
            return True
        try:
            source_handle = citation.get_reference_handle()
            source = database.get_source_from_handle(source_handle)
        except Exception:
            continue
        if _object_has_tag(source, tag_handle, tag_name):
            return True
    return False


def source_ok_vital_dates(
    database,
    handle: str | None,
    tag_handle: str,
    tag_name: str = "Source OK",
) -> tuple[bool, bool]:
    """Return source-tag state for the person's birth and death events.

    The result is a render-neutral pair. Missing, invalid, private, or
    otherwise unreadable events are treated as unvalidated.
    """
    if not handle or not tag_handle:
        return False, False
    try:
        person = database.get_person_from_handle(handle)
        if person is None:
            return False, False
        # Gramps users commonly apply validation tags to the person rather
        # than to each vital event. In that case the tag validates the vital
        # dates as a pair; event/citation/source tags remain supported below.
        if _object_has_tag(person, tag_handle, tag_name):
            return True, True
        birth = get_birth_or_fallback(database, person)
        death = get_death_or_fallback(database, person)
        return (
            _event_has_source_ok_tag(database, birth, tag_handle, tag_name),
            _event_has_source_ok_tag(database, death, tag_handle, tag_name),
        )
    except Exception:
        return False, False


def _place_hierarchy_is_private(database, place) -> bool:
    """Return whether a place or any of its parents is private."""
    pending = [place]
    visited = set()
    while pending:
        current = pending.pop()
        get_handle = getattr(current, "get_handle", None)
        key = get_handle() if callable(get_handle) else id(current)
        if key in visited:
            continue
        visited.add(key)

        privacy_getter = getattr(current, "get_privacy", None)
        try:
            if not callable(privacy_getter) or bool(privacy_getter()):
                return True
        except Exception:
            return True

        parents_getter = getattr(current, "get_placeref_list", None)
        try:
            parent_refs = parents_getter() if callable(parents_getter) else ()
        except Exception:
            return True
        for parent_ref in parent_refs:
            parent_handle = getattr(parent_ref, "ref", None)
            if not parent_handle:
                continue
            parent = database.get_place_from_handle(parent_handle)
            if parent is None:
                return True
            pending.append(parent)
    return False


def format_event_place(
    database,
    event,
    strategy: str,
    *,
    displayer=place_displayer,
    include_private: bool = True,
) -> str:
    """Format one event place through Gramps, then shorten explicitly."""
    if strategy not in {
        "gramps",
        "locality",
        "locality_region",
        "locality_country",
    }:
        raise ValueError(f"unsupported place strategy: {strategy}")
    if event is None:
        return ""
    place_handle = event.get_place_handle()
    if not include_private and place_handle:
        get_place = getattr(database, "get_place_from_handle", None)
        if not callable(get_place):
            return ""
        place = get_place(place_handle)
        if place is None:
            return ""
        privacy_getter = getattr(place, "get_privacy", None)
        try:
            place_is_private = (
                bool(privacy_getter()) if callable(privacy_getter) else True
            )
        except Exception:
            place_is_private = True
        if place_is_private or _place_hierarchy_is_private(database, place):
            return ""
    displayed = displayer.display_event(database, event).strip()
    if not displayed or strategy == "gramps":
        return displayed

    place_handle = event.get_place_handle()
    get_place = getattr(database, "get_place_from_handle", None)
    place = get_place(place_handle) if place_handle and callable(get_place) else None
    if place is not None:
        location = get_main_location(database, place, event.get_date_object())

        def first_of(*place_types):
            return next(
                (
                    location.get(int(place_type), "").strip()
                    for place_type in place_types
                    if location.get(int(place_type), "").strip()
                ),
                "",
            )

        locality = first_of(
            PlaceType.LOCALITY,
            PlaceType.CITY,
            PlaceType.PARISH,
            PlaceType.NEIGHBORHOOD,
            PlaceType.DISTRICT,
            PlaceType.STREET,
        )
        region = first_of(
            PlaceType.DEPARTMENT,
            PlaceType.REGION,
            PlaceType.STATE,
            PlaceType.PROVINCE,
            PlaceType.COUNTY,
        )
        country = first_of(PlaceType.COUNTRY)
        selected = {
            "locality": (locality,),
            "locality_region": (locality, region),
            "locality_country": (locality, country),
        }[strategy]
        if all(selected):
            return ", ".join(selected)

    # A localized display string is not a semantic hierarchy. If Gramps cannot
    # provide typed levels, preserve its complete label rather than guessing
    # locality/region/country from comma positions.
    return displayed


def extract_vital_places(
    database,
    person,
    place_strategy: str,
    *,
    displayer=place_displayer,
) -> tuple[str, str]:
    """Format birth/death places from the same Gramps fallback events as dates."""
    birth = get_birth_or_fallback(database, person)
    death = get_death_or_fallback(database, person)
    return (
        format_event_place(database, birth, place_strategy, displayer=displayer),
        format_event_place(database, death, place_strategy, displayer=displayer),
    )


def _events_for(database, owner, event_type: int, *, primary_only: bool = False):
    events = []
    references = (
        owner.get_primary_event_ref_list()
        if primary_only and hasattr(owner, "get_primary_event_ref_list")
        else owner.get_event_ref_list()
    )
    for reference in references:
        event = database.get_event_from_handle(reference.get_reference_handle())
        if event is not None and event.get_type() == event_type:
            events.append(event)
    return tuple(events)


def _event_year(event) -> int | None:
    date = event.get_date_object()
    if date is None or not date.is_valid():
        return None
    return date.get_year() or None


def select_occupations(
    database,
    person,
    strategy: str = "last_dated",
    *,
    limit: int = 1,
    reference_year: int | None = None,
) -> tuple[str, ...]:
    """Select occupation descriptions using only V1 specification rules."""
    allowed = {
        "first_dated",
        "last_dated",
        "closest_union",
        "distinct",
        "first_nonempty",
    }
    if strategy not in allowed:
        raise ValueError(f"unsupported occupation strategy: {strategy}")
    if limit < 1:
        raise ValueError("occupation limit must be positive")

    candidates = tuple(
        (event, event.get_description().strip(), _event_year(event))
        for event in _events_for(
            database, person, EventType.OCCUPATION, primary_only=True
        )
        if event.get_description().strip()
    )
    if not candidates:
        return ()
    dated = tuple(candidate for candidate in candidates if candidate[2] is not None)

    if strategy == "distinct":
        distinct = []
        for _, text, _ in candidates:
            if text not in distinct:
                distinct.append(text)
        return tuple(distinct[:limit])
    if strategy == "first_nonempty":
        return (candidates[0][1],)
    if strategy == "closest_union":
        if reference_year is None:
            raise ValueError("closest_union requires reference_year")
        if dated:
            selected = min(dated, key=lambda item: abs(item[2] - reference_year))
            return (selected[1],)
        return (candidates[0][1],)
    if dated:
        key = lambda item: item[2]
        selected = min(dated, key=key) if strategy == "first_dated" else max(dated, key=key)
        return (selected[1],)
    return (candidates[0][1],)


def extract_residence(
    database,
    person,
    place_strategy: str,
    date_format: str,
    *,
    locale=glocale,
    displayer=place_displayer,
) -> EventFact | None:
    """Select the latest dated residence, otherwise the first in Gramps order."""
    events = _events_for(
        database, person, EventType.RESIDENCE, primary_only=True
    )
    if not events:
        return None
    dated = tuple(event for event in events if _event_year(event) is not None)
    selected = max(dated, key=_event_year) if dated else events[0]
    return EventFact(
        text=selected.get_description().strip(),
        date_text=format_date(selected.get_date_object(), date_format, locale),
        place=format_event_place(
            database, selected, place_strategy, displayer=displayer
        ),
        year=_event_year(selected),
    )


def extract_union(
    database,
    family,
    date_format: str,
    place_strategy: str,
    *,
    locale=glocale,
    displayer=place_displayer,
    include_private: bool = True,
    occurrence: int = 1,
) -> EventFact | None:
    """Extract the first permitted marriage event in the family's order."""
    events = _events_for(database, family, EventType.MARRIAGE)
    if not include_private:
        events = tuple(
            event
            for event in events
            if not bool(getattr(event, "get_privacy", lambda: False)())
        )
    if not events:
        return None
    selected = events[0]
    return EventFact(
        text=selected.get_description().strip(),
        date_text=format_event_date(
            selected.get_date_object(),
            date_format,
            EventType.MARRIAGE,
            occurrence=occurrence,
            locale=locale,
        ),
        place=format_event_place(
            database,
            selected,
            place_strategy,
            displayer=displayer,
            include_private=include_private,
        ),
        year=_event_year(selected),
    )


_INFORMATION_ZONES = {
    "central_couple",
    "ancestor_inner",
    "ancestor_outer",
    "children_spouses",
    "descendant_outer",
}


def _lifespan(vitals: VitalDates) -> str:
    birth = vitals.birth.text or (
        f"° {vitals.birth.year}" if vitals.birth.year else ""
    )
    death = vitals.death.text or (
        f"† {vitals.death.year}" if vitals.death.year else ""
    )
    return " – ".join(
        text for text in (birth, death) if text
    )


def _event_fact_label(fact: EventFact | None) -> str:
    if fact is None:
        return ""
    parts = tuple(
        value.strip()
        for value in (fact.date_text, fact.place, fact.text)
        if value and value.strip()
    )
    return " · ".join(dict.fromkeys(parts))


def build_information_profile(
    zone: str,
    labels,
    vitals: VitalDates,
    *,
    family_summary: str = "",
    child_count: int | None = None,
    birth_place: str = "",
    death_place: str = "",
    occupations: tuple[str, ...] = (),
    number_label: str = "",
    residence: EventFact | None = None,
    union: EventFact | None = None,
    include_places: bool = False,
    include_occupation: bool = False,
    include_residence: bool = False,
    include_union: bool = False,
) -> InformationProfile:
    """Build prioritized semantic lines for the five V1 chart zones."""
    if zone not in _INFORMATION_ZONES:
        raise ValueError(f"unsupported information zone: {zone}")

    lines = [InformationLine("name", labels.short_label, 1)]
    if zone == "central_couple" and labels.full_label != labels.short_label:
        lines.append(InformationLine("full_name", labels.full_label, 2))

    lifespan = _lifespan(vitals)
    if zone == "descendant_outer":
        if lifespan:
            lines.append(InformationLine("vital_years", lifespan, 4))
    elif lifespan:
        lines.append(InformationLine("lifespan", lifespan, 4))

    if zone == "children_spouses" and child_count is not None:
        lines.append(InformationLine("children", str(child_count), 5))
    if include_places:
        if birth_place:
            lines.append(InformationLine("birth_place", birth_place, 6))
        if death_place:
            lines.append(InformationLine("death_place", death_place, 6))
    if include_occupation and occupations:
        lines.append(InformationLine("occupation", "; ".join(occupations), 7))
    if include_union:
        union_label = _event_fact_label(union)
        if union_label:
            lines.append(InformationLine("union", union_label, 5))
    if include_residence:
        residence_label = _event_fact_label(residence)
        if residence_label:
            lines.append(InformationLine("residence", residence_label, 6))
    if zone == "central_couple" and family_summary:
        lines.append(InformationLine("family_summary", family_summary, 8))
    if number_label:
        lines.append(InformationLine("numbering", number_label, 8))

    return InformationProfile(
        zone, tuple(sorted(lines, key=lambda line: line.priority))
    )


def sosa_number(
    generation: int,
    index: int,
    *,
    enabled: bool = True,
) -> str | None:
    """Return the Sosa number for a zero-based slot in an ancestor generation."""
    if not enabled:
        return None
    if generation < 1 or index < 0 or index >= 2**generation:
        raise ValueError("invalid Sosa slot")
    return str(2**generation + index)


def daboville_number(
    path: tuple[int, ...],
    *,
    enabled: bool = True,
) -> str | None:
    """Return a d'Aboville label for a deterministic one-based child path."""
    if not enabled:
        return None
    if not path or any(index < 1 for index in path):
        raise ValueError("invalid d'Aboville path")
    return ".".join(str(index) for index in path)


_EMPTY_VITALS = VitalDates(
    VitalFact("", None, False),
    VitalFact("", None, False),
)


def simple_name(database, handle: str | None) -> str:
    """Return the preferred short display name for a person handle.

    Priority is: call name, then the first given name as a fallback. A
    nickname is appended to that usage-name candidate. The surname is
    returned in Gramps' ``Surname, Given`` order and is reordered by the
    layout layer when needed. Only the usage name is retained; other given
    names never reach the chart label.
    """
    if not handle:
        return ""
    person = database.get_person_from_handle(handle)
    if person is None:
        return ""
    name = person.get_primary_name()

    try:
        call = name.get_call_name().strip()
    except Exception:
        call = ""

    try:
        nickname = name.get_nick_name().strip()
    except Exception:
        nickname = ""

    if call:
        given = call
    else:
        first_name = name.get_first_name().strip()
        given = first_name.split()[0] if first_name else ""
    if nickname:
        given = f'{given} "{nickname}"'.strip()

    surname = ""
    try:
        surnames = [s.get_surname() for s in name.get_surname_list() if s.get_surname()]
        surname = " ".join(surnames).strip()
    except Exception:
        pass

    if surname and given:
        return f"{surname}, {given}"
    if surname:
        return surname
    return given


def simple_name_full(database, handle: str | None) -> str:
    """Return a full display name (all given names) for the center couple."""
    if not handle:
        return ""
    person = database.get_person_from_handle(handle)
    if person is None:
        return ""
    name = person.get_primary_name()
    try:
        from gramps.gen.display.name import displayer as name_displayer
        label = name_displayer.display_name(name).strip(" ,")
        return label or ""
    except Exception:
        given = name.get_first_name().strip()
        surname = " ".join(
            s.get_surname()
            for s in name.get_surname_list()
            if s.get_surname()
        ).strip()
        return f"{given} {surname}".strip()


def simple_dates(database, handle: str | None) -> str:
    """Return a compact life-years label for a person handle.

    Returns one of:
      - "° YYYY – † YYYY" when both birth and death years are known
      - "° YYYY"          when only birth year is known
      - "† YYYY"          when only death year is known
      - ""                when neither is known

    Uses Gramps' fallback birth/death event search so that christening
    or burial events are considered when birth/death are missing.
    """
    if not handle:
        return ""
    person = database.get_person_from_handle(handle)
    if person is None:
        return ""
    try:
        birth = get_birth_or_fallback(database, person)
        death = get_death_or_fallback(database, person)
    except Exception:
        return ""
    birth_fact = _event_fact(
        birth,
        getattr(person, "get_birth_ref", lambda: None)(),
        "years",
        glocale,
        EventType.BIRTH,
    )
    death_fact = _event_fact(
        death,
        getattr(person, "get_death_ref", lambda: None)(),
        "years",
        glocale,
        EventType.DEATH,
    )
    return " – ".join(
        text for text in (birth_fact.text, death_fact.text) if text
    )


def build_person_view(
    seed: PersonViewSeed,
    database,
    person,
    config,
    zone: str,
    *,
    family=None,
    family_summary: str = "",
    child_count: int | None = None,
    ancestor_slot: tuple[int, int] | None = None,
    descendant_path: tuple[int, ...] | None = None,
    union_year: int | None = None,
    marriage_occurrence: int = 1,
    locale=glocale,
    name_formats=None,
) -> PersonView:
    """Format a sanitized seed and read details only for fully visible people."""
    if not isinstance(seed, PersonViewSeed):
        raise ValueError("person view requires a sanitized PersonViewSeed")
    if seed.visibility is VisibilityState.EXCLUDED:
        raise ValueError("excluded person cannot produce a PersonView")

    formatter = NameFormatter.from_config(
        config,
        locale=locale,
        name_formats=name_formats,
    )
    labels = derive_name_labels(
        seed,
        formatter,
        short_strategy=getattr(config, "given_name_strategy", "call_then_first"),
    )

    date_format = getattr(config, "date_format", "years")
    place_strategy = getattr(config, "place_strategy", "locality")
    show_places = bool(getattr(config, "show_places", False))
    show_occupation = bool(getattr(config, "show_occupation", False))
    occupation_strategy = getattr(config, "occupation_strategy", "last_dated")
    occupation_maximum = getattr(config, "occupation_maximum", 1)
    show_residence = bool(getattr(config, "show_residence", False))
    show_union = bool(getattr(config, "show_union", False))
    show_sosa = bool(getattr(config, "show_sosa", False))
    show_daboville = bool(getattr(config, "show_daboville", False))

    vitals = _EMPTY_VITALS
    birth_place = death_place = ""
    occupations: tuple[str, ...] = ()
    residence = None
    union = None
    number_label = ""
    if seed.visibility is VisibilityState.VISIBLE:
        vitals = extract_vital_dates(database, person, date_format, locale)
        if show_places:
            birth_place, death_place = extract_vital_places(
                database, person, place_strategy
            )
        if show_occupation:
            occupations = select_occupations(
                database,
                person,
                occupation_strategy,
                limit=occupation_maximum,
                reference_year=union_year,
            )
        if show_residence:
            residence = extract_residence(
                database,
                person,
                place_strategy,
                date_format,
                locale=locale,
            )
        if show_union and family is not None:
            union = extract_union(
                database,
                family,
                date_format,
                place_strategy,
                locale=locale,
                occurrence=marriage_occurrence,
            )
        if show_sosa and ancestor_slot is not None:
            number_label = f"Sosa {sosa_number(*ancestor_slot)}"
        elif show_daboville and descendant_path is not None:
            number_label = f"d’Aboville {daboville_number(descendant_path)}"
    else:
        family_summary = ""
        child_count = None
        number_label = ""

    information = build_information_profile(
        zone,
        labels,
        vitals,
        family_summary=family_summary,
        child_count=child_count,
        birth_place=birth_place,
        death_place=death_place,
        occupations=occupations,
        number_label=number_label,
        residence=residence,
        union=union,
        include_places=show_places and seed.visibility is VisibilityState.VISIBLE,
        include_occupation=(
            show_occupation and seed.visibility is VisibilityState.VISIBLE
        ),
        include_residence=(
            show_residence and seed.visibility is VisibilityState.VISIBLE
        ),
        include_union=show_union and seed.visibility is VisibilityState.VISIBLE,
    )
    return PersonView(
        seed=seed,
        full_label=labels.full_label,
        short_label=labels.short_label,
        name_case=labels.name_case,
        vital_dates=vitals,
        information=information,
        residence=residence,
        union=union,
    )
