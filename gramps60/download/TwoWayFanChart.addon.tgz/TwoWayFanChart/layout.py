# SPDX-License-Identifier: GPL-3.0-or-later
"""Page canvas layout calculations for the two-way fan chart."""

from __future__ import annotations

import math
from dataclasses import dataclass

try:
    from TwoWayFanChart.geometry import PaperRegion, polar_to_cartesian, deg2rad
    from TwoWayFanChart.model import (
        DescendantBranch,
        SceneCircle,
        SceneImage,
        SceneMarker,
        SceneLegend,
        SceneNode,
        SceneRect,
        SceneSector,
        SceneText,
        ScenePathText,
        estimate_text_width,
    )
    from TwoWayFanChart.styles import (
        ancestor_fill,
        descendant_fill,
        MEDALLION_BORDER,
        MEDALLION_FILL,
        HIDDEN_FILL,
        TEXT_DARK,
        TEXT_GREY,
        SECTOR_STROKE,
        SECTOR_STROKE_WIDTH,
    )
except ModuleNotFoundError:
    from geometry import PaperRegion, polar_to_cartesian, deg2rad  # type: ignore[no-redef]
    from model import (  # type: ignore[no-redef]
        DescendantBranch,
        SceneCircle,
        SceneImage,
        SceneMarker,
        SceneLegend,
        SceneNode,
        SceneRect,
        SceneSector,
        SceneText,
        ScenePathText,
        estimate_text_width,
    )
    from styles import (  # type: ignore[no-redef]
        ancestor_fill,
        descendant_fill,
        MEDALLION_BORDER,
        MEDALLION_FILL,
        HIDDEN_FILL,
        TEXT_DARK,
        TEXT_GREY,
        SECTOR_STROKE,
        SECTOR_STROKE_WIDTH,
    )


# ---------------------------------------------------------------------------
# Layout constants (mm) — defaults from spec §5.6
# ---------------------------------------------------------------------------

_TITLE_ZONE_MM = 14.0  # title + subtitle area
_LEGEND_ZONE_MM = 18.0  # legend at bottom
_STATS_ZONE_MM = 6.0  # statistics line
_MIN_CENTER_RADIUS_MM = 8.0  # minimum medallion radius
_RING_GAP_MM = 0.3  # white space between generation rings
_DESCENDANT_FIRST_GEN_LINE_GAP_MM = 5.0  # minimum readable baseline gap
# The publication composition gives the descendant quarter a smaller visual
# footprint than the ancestor fan. Keep the ratio explicit so the A0 maquette
# and its regression probes share one geometric contract.
_DESCENDANT_OUTER_RADIUS_RATIO = 0.76
_DESCENDANT_MEDALLION_TARGET_RATIO = 28 / 600


@dataclass(frozen=True, slots=True)
class ChartCanvas:
    """Pre-calculated page regions for a two-way fan chart."""

    page_width_mm: float
    page_height_mm: float
    content_width_mm: float
    content_height_mm: float
    title_zone_mm: float
    legend_zone_mm: float
    center_radius_mm: float
    ancestor_inner_radius_mm: float
    ancestor_outer_radius_mm: float
    descendant_inner_radius_mm: float
    descendant_outer_radius_mm: float
    center_cx_mm: float
    center_cy_mm: float


def calculate_canvas(
    paper: PaperRegion,
    *,
    ancestor_generations: int,
    descendant_generations: int,
) -> ChartCanvas:
    """Calculate all page regions from paper size, margins, and generation counts.

    The layout fills the page: the center medallion occupies ~18% of the
    available radius, while the descendant quarter intentionally uses a
    compact outer radius so it does not visually compete with the ancestor fan.
    """
    content_w = paper.content_width_mm
    content_h = paper.content_height_mm

    title_zone = _TITLE_ZONE_MM
    legend_zone = _LEGEND_ZONE_MM + _STATS_ZONE_MM

    # Legend, stats card and family summary are intentionally omitted from the
    # publication scene. Keep their dimensions in ChartCanvas for API
    # compatibility, but do not reserve blank page bands for absent content.
    available_h = content_h
    available_w = content_w

    # Fill almost the complete content height while retaining enough room for
    # the two small-cap titles just outside the fan.
    max_radius = min(available_h / 2, available_w / 2) * 0.94

    # Center zone: the mockup uses 190 px inside a 600 px fan radius.
    # The ancestor/descendant rings start at this radius.
    center_radius = max(_MIN_CENTER_RADIUS_MM, max_radius * (190.0 / 600.0))

    # Ancestor generations use the full publication radius. Descendants remain
    # anchored on the same center ring but use a compact outer quarter; this
    # leaves useful breathing room below the chart and keeps the lower visual
    # mass subordinate to the accepted A0 ancestor composition.
    ancestor_outer = max_radius if ancestor_generations > 0 else center_radius
    descendant_outer = (
        max_radius * _DESCENDANT_OUTER_RADIUS_RATIO
        if descendant_generations > 0
        else center_radius
    )

    cx = paper.effective_margin_left_mm + content_w / 2
    cy = paper.effective_margin_top_mm + content_h / 2

    return ChartCanvas(
        page_width_mm=paper.width_mm,
        page_height_mm=paper.height_mm,
        content_width_mm=content_w,
        content_height_mm=content_h,
        title_zone_mm=title_zone,
        legend_zone_mm=legend_zone,
        center_radius_mm=center_radius,
        ancestor_inner_radius_mm=center_radius,
        ancestor_outer_radius_mm=ancestor_outer,
        descendant_inner_radius_mm=center_radius,
        descendant_outer_radius_mm=descendant_outer,
        center_cx_mm=cx,
        center_cy_mm=cy,
    )


# ---------------------------------------------------------------------------
# Polar coordinate helpers (using the geometry module convention)
# ---------------------------------------------------------------------------

def _polar(cx: float, cy: float, r: float, angle_deg: float) -> tuple[float, float]:
    """Convert polar to cartesian. Angle 0=up, positive=clockwise (SVG convention)."""
    return polar_to_cartesian(r, deg2rad(angle_deg), cx, cy)


def _arc_text_path(
    cx: float, cy: float, r: float,
    start_angle: float, end_angle: float,
    *,
    lower: bool = False,
) -> str:
    """Build an SVG arc path suitable for textPath text placement.

    For upper-half sectors (ancestors), text reads left-to-right along the arc.
    For lower-half sectors (descendants), text is flipped to remain upright.
    """
    # Add a small margin so text doesn't touch sector boundaries
    margin = min(2.0, max(0.3, (end_angle - start_angle) * 0.06))
    a0 = start_angle + margin
    a1 = end_angle - margin
    if a1 <= a0:
        a0, a1 = start_angle, end_angle

    if lower:
        # For lower half, draw arc right-to-left so text is upright
        x1, y1 = _polar(cx, cy, r, a1)
        x2, y2 = _polar(cx, cy, r, a0)
        large = 1 if abs(a1 - a0) > 180 else 0
        return f"M {x1:.4f} {y1:.4f} A {r:.4f} {r:.4f} 0 {large} 0 {x2:.4f} {y2:.4f}"
    else:
        # For upper half, draw arc left-to-right
        x1, y1 = _polar(cx, cy, r, a0)
        x2, y2 = _polar(cx, cy, r, a1)
        large = 1 if abs(a1 - a0) > 180 else 0
        return f"M {x1:.4f} {y1:.4f} A {r:.4f} {r:.4f} 0 {large} 1 {x2:.4f} {y2:.4f}"


# ---------------------------------------------------------------------------
# Position ID parsing (extract.py uses "ancestor-{lineage}-{gen}-{index}")
# ---------------------------------------------------------------------------

def _parse_position_id(pid: str) -> tuple[str, int] | None:
    """Parse a position_id like 'ancestor-a-1-0' into (lineage, generation)."""
    if not pid:
        return None
    parts = pid.split("-")
    if len(parts) >= 4 and parts[0] == "ancestor":
        lineage = parts[1]
        try:
            gen = int(parts[2])
            return (lineage, gen)
        except ValueError:
            pass
    return None


def _extract_initials(label: str) -> str:
    """Extract initials from a display name like 'Doe, Jane' -> 'DJ'."""
    if not label:
        return ""
    if label in {"Personne privée", "Personnes privées"}:
        return "•"
    parts = label.replace(",", " ").split()
    parts = [p for p in parts if p and p[0].isalpha()]
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0][:2].upper()
    # Use first letter of first name + first letter of last name
    return (parts[0][0] + parts[-1][0]).upper()


def _outward_radial_rotation(deg: float) -> float:
    """Rotate a horizontal baseline onto the sector's radial axis.

    Chart angles use 0° at the top while SVG text starts horizontally. The
    -90° correction aligns the baseline with the center-to-sector vector; the
    optional half-turn then keeps labels upright on the left side.
    """
    rot = deg - 90.0
    normalized = rot % 360
    if 90 < normalized < 270:
        rot += 180
    return rot


def _tangent_offset(
    x: float,
    y: float,
    angle_deg: float,
    offset: float,
) -> tuple[float, float]:
    """Move a polar point along its local clockwise tangent."""
    angle = math.radians(angle_deg)
    return x + math.cos(angle) * offset, y + math.sin(angle) * offset


def _fit_text_to_width(
    content: str,
    *,
    target_size: float,
    minimum_size: float,
    max_width: float,
    allow_ellipsis: bool = True,
) -> tuple[str, float, float]:
    """Fit text to a physical lane while retaining both identity ends."""
    available = max(max_width, 0.5 if not allow_ellipsis else 0.0)
    if not content or available <= 0:
        return "", max(minimum_size, 0.0), available

    natural_at_one = estimate_text_width(content, 1.0)
    size = target_size
    if natural_at_one > 0:
        size = min(target_size, available / natural_at_one)
    size = max(minimum_size, size)

    fitted = content
    if allow_ellipsis and estimate_text_width(fitted, size) > available:
        left = (len(content) + 1) // 2
        right = len(content) - left
        while left + right > 1:
            candidate = content[:left].rstrip() + "…" + content[len(content) - right:].lstrip()
            if estimate_text_width(candidate, size) <= available:
                fitted = candidate
                break
            if left >= right:
                left -= 1
            else:
                right -= 1
        else:
            fitted = "…" if estimate_text_width("…", size) <= available else ""
    return fitted, size, available


def _fit_couple_to_width(
    child_label: str,
    spouse_label: str,
    *,
    target_size: float,
    minimum_size: float,
    max_width: float,
) -> tuple[str, float, float]:
    """Fit a compact couple label while retaining both identities and ``×``."""
    separator = " × "
    combined = f"{child_label}{separator}{spouse_label}"
    natural_at_one = estimate_text_width(combined, 1.0)
    fitted_size = target_size
    if natural_at_one > 0:
        fitted_size = min(target_size, max_width / natural_at_one)
    if fitted_size >= minimum_size:
        return combined, fitted_size, max_width

    separator_width = estimate_text_width(separator, minimum_size)
    label_width = max(0.0, (max_width - separator_width) / 2.0)
    child_fitted, _size, _width = _fit_text_to_width(
        child_label,
        target_size=minimum_size,
        minimum_size=minimum_size,
        max_width=label_width,
    )
    spouse_fitted, _size, _width = _fit_text_to_width(
        spouse_label,
        target_size=minimum_size,
        minimum_size=minimum_size,
        max_width=label_width,
    )
    if not child_fitted or not spouse_fitted:
        return "", minimum_size, max_width
    return f"{child_fitted}{separator}{spouse_fitted}", minimum_size, max_width


def _maximum_medallion_radius(
    *,
    inner_radius: float,
    outer_radius: float,
    sweep_angle: float,
    occupants: int = 1,
    edge: str = "outer",
    margin: float = 0.8,
) -> float:
    """Solve the largest border radius fitting a sector at one ring edge."""
    radial_cap = max(0.0, (outer_radius - inner_radius - 2 * margin) / 2.0)
    low, high = 0.0, radial_cap
    occupants = max(1, occupants)
    for _ in range(32):
        radius = (low + high) / 2.0
        center_radius = (
            outer_radius - margin - radius
            if edge == "outer"
            else inner_radius + margin + radius
        )
        tangent_capacity = max(
            0.0,
            2.0 * center_radius * math.sin(math.radians(max(sweep_angle, 0.0) / 2.0))
            - 2.0 * margin,
        )
        required = 2.0 * radius if occupants == 1 else (4.3 * radius)
        if required <= tangent_capacity:
            low = radius
        else:
            high = radius
    return low


def _ancestor_content_geometry(
    *,
    generation: int,
    inner_radius: float,
    outer_radius: float,
    fan_outer_radius: float,
    sweep_angle: float,
) -> tuple[float, float, float, float, float, float, bool, bool]:
    """Return ring-relative placement and density-aware ancestor styling.

    The original mockup coordinates were global fractions of a three-ring fan.
    Reusing those fractions with a different generation count moved content into
    neighbouring rings. Local fractions preserve the three-ring hierarchy while
    adapting to every supported ring depth.
    """
    ring_depth = max(outer_radius - inner_radius, 0.0)
    portrait_fractions = {1: 0.365, 2: 0.353, 3: 0.280}
    name_fractions = {1: 0.652, 2: 0.684, 3: 0.630}
    life_fractions = {1: 0.826, 2: 0.841, 3: 0.761}
    portrait_r = inner_radius + ring_depth * portrait_fractions.get(generation, 0.28)
    name_r = inner_radius + ring_depth * name_fractions.get(generation, 0.58)
    life_r = inner_radius + ring_depth * life_fractions.get(generation, 0.78)

    # Give the publication-facing ancestor portraits more presence while
    # leaving the actual radius bounded by each ring's radial and tangent
    # capacity. The G2 reference was 20/600, which made portraits recede on A0.
    base_image_ratios = {1: 30 / 600, 2: 25 / 600, 3: 18 / 600}
    base_name_ratios = {1: 12 / 600, 2: 12 / 600, 3: 10.5 / 600}
    base_life_ratios = {1: 9.5 / 600, 2: 9.5 / 600, 3: 8.5 / 600}
    base_image_r = base_image_ratios.get(
        generation, (15 / 600) * (0.86 ** (generation - 3))
    ) * fan_outer_radius
    base_name_size = base_name_ratios.get(
        generation, (10 / 600) * (0.90 ** (generation - 3))
    ) * fan_outer_radius
    base_life_size = base_life_ratios.get(
        generation, (8.5 / 600) * (0.90 ** (generation - 3))
    ) * fan_outer_radius

    # Keep medallions inside both their radial ring and angular lane. For the
    # dense fourth and fifth rings, solve against the actual sector and hug the
    # inner edge so the remaining radial depth is reserved for labels.
    angular_lane = portrait_r * math.radians(max(sweep_angle, 0.0))
    if generation >= 4:
        image_r = _maximum_medallion_radius(
            inner_radius=inner_radius,
            outer_radius=outer_radius,
            sweep_angle=sweep_angle,
            edge="inner",
            margin=0.8,
        )
        portrait_r = inner_radius + 0.8 + image_r
    else:
        image_r = min(base_image_r, ring_depth * 0.24, angular_lane * 0.22)
    name_size = min(base_name_size, ring_depth * 0.12, angular_lane * 0.36)
    life_size = min(base_life_size, ring_depth * 0.10, angular_lane * 0.30)
    # Per-generation caps ensure a monotonic font hierarchy: deeper
    # generations always have a strictly smaller maximum name size than
    # shallower ones, regardless of how much radial width the medallion
    # leaves.  Without this, G4/G5 (small medallions, more text width)
    # can render at a larger font than G3 (large medallion, less width).
    _name_caps = {1: 7.0, 2: 6.0, 3: 5.0, 4: 4.2, 5: 3.5}
    _life_caps = {1: 5.5, 2: 4.8, 3: 4.0, 4: 3.4, 5: 2.8}
    name_cap = _name_caps.get(generation, 3.0)
    life_cap = _life_caps.get(generation, 2.5)
    name_size = max(min(name_size, name_cap), 2.8)
    life_size = max(min(life_size, life_cap), 2.5)

    text_start = portrait_r + image_r + 2.0
    text_available = max(0.0, outer_radius - 1.5 - text_start)
    # A0 has ample radial depth in generation five despite its 2.688° sweep.
    # Protect names through generation five whenever a useful radial lane exists;
    # deeper rings retain the stricter density degradation policy.
    show_text = (
        generation <= 4
    ) or (
        generation == 5 and text_available >= 12.0 and angular_lane >= 4.0
    ) or (
        generation > 5 and sweep_angle >= 4.0 and name_size >= 1.4
    )
    show_medallion = sweep_angle >= 2.0 and image_r >= 0.8
    return (
        portrait_r,
        name_r,
        life_r,
        image_r,
        name_size,
        life_size,
        show_text,
        show_medallion,
    )


# ---------------------------------------------------------------------------
# Ancestor fan placement
# ---------------------------------------------------------------------------

_ANCESTOR_HALF_SPAN_DEG = 86.0  # mockup: 172° total, 4° waist gap per side


def layout_ancestors(
    canvas: ChartCanvas,
    ancestor_slots: tuple[tuple, ...],
    *,
    show_highlight_markers: bool = False,
) -> SceneNode:
    """Place ancestor fan sectors in the upper half-circle.

    ancestor_slots is a flat tuple of (position_id, label, dates_label) triples.
    Position IDs following the pattern "ancestor-{lineage}-{gen}-{index}"
    are parsed to determine generation and lineage for coloring.
    Empty position_id means an empty/unknown slot (blank sector).

    Generates:
    - Colored annular sectors with mockup palette colors
    - Curved text labels (ScenePathText) along arc paths
    - A second curved arc with life-year dates
    - Small medallion circles with initials at the outer edge of each sector
    - Lineage labels (LIGNÉE <surname>) at the gap between the two halves

    Highlight markers are opt-in so publication views do not expose tag
    annotations unless explicitly requested.
    """
    if not ancestor_slots:
        return SceneNode(children=())

    cx = canvas.center_cx_mm
    cy = canvas.center_cy_mm
    inner_r = canvas.ancestor_inner_radius_mm
    outer_r = canvas.ancestor_outer_radius_mm

    # Parse all slots to get
    # (pid, lineage, generation, label, dates_label, portrait_data_uri).
    parsed: list[tuple[str, str, int, str, str, str | None, bool]] = []
    for entry in ancestor_slots:
        if len(entry) >= 4:
            pid, label, dates_label, portrait = (
                entry[0], entry[1], entry[2], entry[3]
            )
            highlighted = (
                bool(entry[4])
                if show_highlight_markers and len(entry) >= 5
                else False
            )
        elif len(entry) == 3:
            pid, label, dates_label = entry[0], entry[1], entry[2]
            portrait = None
            highlighted = False
        elif len(entry) >= 2:
            # Backward-compatible 2-tuple (position_id, label)
            pid, label = entry[0], entry[1]
            dates_label = ""
            portrait = None
            highlighted = False
        else:
            continue
        info = _parse_position_id(pid)
        if info:
            lineage, gen = info
        else:
            # Fallback: determine from position in list
            lineage = "a"
            gen = 1
        parsed.append((pid, lineage, gen, label, dates_label, portrait, highlighted))

    # Determine actual generations present
    max_gen = max(g for _, _, g, _, _, _, _ in parsed) if parsed else 1
    num_gens = max_gen

    total_depth = outer_r - inner_r
    # Mockup ancestor rings widen outwards: 113 px, 125 px, 148 px.
    # The formula reproduces those proportions for three generations and
    # degrades progressively for deeper configurations.
    if num_gens > 0:
        weights = [1.0 + 0.105 * i + 0.05 * i * (i - 1) for i in range(num_gens)]
        total_weight = sum(weights)
        ring_widths = [total_depth * weight / total_weight for weight in weights]
    else:
        ring_widths = [total_depth]

    children: list = []

    # Collect the gen-1 surname per lineage for the LIGNÉE labels.
    lineage_surnames: dict[str, str] = {}
    for pid, lineage, gen, label, _dates, _portrait, _highlighted in parsed:
        if gen == 1 and label:
            # Label is "Surname, Given…" — take the part before the comma.
            if ", " in label:
                surname = label.split(", ", 1)[0]
            elif "," in label:
                surname = label.split(",", 1)[0]
            else:
                # Plain "Given Surname" — last word is the surname.
                surname = label.split()[-1] if label.split() else ""
            surname = surname.strip()
            if surname:
                lineage_surnames.setdefault(lineage, surname)

    # Group slots by generation
    for gen in range(1, num_gens + 1):
        gen_inner = inner_r + sum(ring_widths[:gen-1])
        ring_width = ring_widths[gen - 1]
        gen_outer = gen_inner + ring_width - _RING_GAP_MM

        gen_slots = [
            (pid, lin, lbl, dt, portrait, highlighted)
            for pid, lin, g, lbl, dt, portrait, highlighted in parsed
            if g == gen
        ]
        if not gen_slots:
            continue

        # Split into lineage a (left: -90° to 0°) and lineage b (right: 0° to 90°)
        slots_a = [s for s in gen_slots if s[1] == "a"]
        slots_b = [s for s in gen_slots if s[1] == "b"]

        # If no lineage info (all same), split by index
        if not slots_b and slots_a:
            half = len(gen_slots) // 2
            slots_a = gen_slots[:half]
            slots_b = gen_slots[half:]

        sweep_a = _ANCESTOR_HALF_SPAN_DEG / max(len(slots_a), 1) if slots_a else 0
        sweep_b = _ANCESTOR_HALF_SPAN_DEG / max(len(slots_b), 1) if slots_b else 0

        # Place lineage a (paternal, left side: -90° to 0°)
        for i, (pid, _, label, dates_label, portrait, highlighted) in enumerate(slots_a):
            start_angle = -_ANCESTOR_HALF_SPAN_DEG + i * sweep_a
            _emit_ancestor_sector(
                children, cx, cy, gen_inner, gen_outer,
                start_angle, sweep_a, outer_r,
                gen, "a", label, dates_label, portrait, highlighted,
            )

        # Place lineage b (maternal, right side: 0° to 90°)
        for i, (pid, _, label, dates_label, portrait, highlighted) in enumerate(slots_b):
            start_angle = 0.0 + i * sweep_b
            _emit_ancestor_sector(
                children, cx, cy, gen_inner, gen_outer,
                start_angle, sweep_b, outer_r,
                gen, "b", label, dates_label, portrait, highlighted,
            )

    return SceneNode(children=tuple(children))


def _emit_ancestor_sector(
    children: list,
    cx: float, cy: float,
    inner_r: float, outer_r: float,
    start_angle: float, sweep: float,
    fan_outer_r: float,
    gen: int, lineage: str,
    label: str,
    dates_label: str = "",
    portrait: str | None = None,
    highlighted: bool = False,
) -> None:
    """Emit one ancestor sector with fill, curved label, dates, and medallion."""
    end_angle = start_angle + sweep
    mid_angle = start_angle + sweep / 2.0

    fill = ancestor_fill(gen, lineage)
    if not label:
        # Empty slot — use a neutral light fill
        fill = "#F0EEE6"

    children.append(SceneSector(
        inner_radius=inner_r,
        outer_radius=outer_r,
        start_angle=start_angle,
        sweep_angle=sweep,
        fill=fill,
        stroke=SECTOR_STROKE,
        stroke_width=SECTOR_STROKE_WIDTH,
        cx=cx,
        cy=cy,
    ))

    if not label:
        return

    (
        med_r_pos,
        name_r,
        life_r,
        image_r,
        font_size,
        life_font,
        show_text,
        show_medallion,
    ) = _ancestor_content_geometry(
        generation=gen,
        inner_radius=inner_r,
        outer_radius=outer_r,
        fan_outer_radius=fan_outer_r,
        sweep_angle=sweep,
    )
    # Narrow sectors need true radial text; broad sectors retain curved labels.
    use_radial = sweep < 15.0
    adaptive_tracks = use_radial and gen >= 3
    if gen >= 4:
        med_r = image_r
        portrait_image_r = image_r * (24 / 26)
    else:
        med_r = image_r * (26 / 24) if portrait else image_r
        portrait_image_r = image_r

    if show_text and adaptive_tracks:
        text_start = med_r_pos + med_r + 2.0
        text_end = outer_r - 1.5
        text_width = max(0.0, text_end - text_start)
        text_r = (text_start + text_end) / 2.0
        base_x, base_y = _polar(cx, cy, text_r, mid_angle)
        rot = _outward_radial_rotation(mid_angle)
        lane_offset = max(font_size, life_font) * 0.58

        # --- Name fitting -------------------------------------------------
        # Fit the full label on one line first.  If the result is badly
        # shrunk (the large G3 medallion eats radial width), split into two
        # lines: given name above, surname below.  Each shorter line fits
        # at a larger font size, which keeps the hierarchy monotonic across
        # generations instead of letting G4/G5 (small medallions, more
        # text width) render larger than G3.
        fitted_name, fitted_name_size, name_width = _fit_text_to_width(
            label,
            target_size=font_size,
            minimum_size=2.8,
            max_width=text_width,
            allow_ellipsis=False,
        )
        use_two_lines = False
        two_line_size = 0.0
        fitted_given = ""
        fitted_surname = ""
        given_width = 0.0
        surname_width = 0.0
        if fitted_name_size < font_size * 0.75 and ", " in label:
            surname_part, given_part = label.split(", ", 1)
            fitted_given, given_size, given_width = _fit_text_to_width(
                given_part,
                target_size=font_size,
                minimum_size=2.8,
                max_width=text_width,
                allow_ellipsis=False,
            )
            fitted_surname, surname_size, surname_width = _fit_text_to_width(
                surname_part,
                target_size=font_size,
                minimum_size=2.8,
                max_width=text_width,
                allow_ellipsis=False,
            )
            two_line_size = min(given_size, surname_size)
            if two_line_size > fitted_name_size * 1.15:
                use_two_lines = True

        effective_name_size = (
            two_line_size if use_two_lines else fitted_name_size
        )

        if use_two_lines:
            line_h = two_line_size * 1.3
            gx, gy = _tangent_offset(base_x, base_y, mid_angle, -line_h)
            sx, sy = _tangent_offset(base_x, base_y, mid_angle, 0.0)
            if fitted_given:
                children.append(SceneText(
                    x=gx, y=gy,
                    content=fitted_given,
                    font_size=two_line_size,
                    fill=TEXT_DARK,
                    anchor="middle",
                    rotation=rot,
                    max_width=given_width,
                ))
            if fitted_surname:
                children.append(SceneText(
                    x=sx, y=sy,
                    content=fitted_surname,
                    font_size=two_line_size,
                    fill=TEXT_DARK,
                    anchor="middle",
                    rotation=rot,
                    max_width=surname_width,
                ))
        elif fitted_name:
            name_x, name_y = _tangent_offset(
                base_x, base_y, mid_angle, -lane_offset,
            )
            children.append(SceneText(
                x=name_x,
                y=name_y,
                content=fitted_name,
                font_size=fitted_name_size,
                fill=TEXT_DARK,
                anchor="middle",
                rotation=rot,
                max_width=name_width,
            ))

        # --- Dates --------------------------------------------------------
        # Date font must never exceed the name font.
        if dates_label:
            date_target = min(life_font, effective_name_size)
            if use_two_lines:
                dx, dy = _tangent_offset(
                    base_x, base_y, mid_angle, line_h,
                )
            else:
                dx, dy = _tangent_offset(
                    base_x, base_y, mid_angle, lane_offset,
                )
            fitted_dates, fitted_date_size, date_width = _fit_text_to_width(
                dates_label,
                target_size=date_target,
                minimum_size=2.5,
                max_width=text_width,
            )
            fitted_date_size = min(fitted_date_size, effective_name_size)
            if fitted_dates:
                children.append(SceneText(
                    x=dx,
                    y=dy,
                    content=fitted_dates,
                    font_size=fitted_date_size,
                    fill=TEXT_GREY,
                    anchor="middle",
                    rotation=rot,
                    max_width=date_width,
                ))
    elif show_text and use_radial:
        tx, ty = _polar(cx, cy, name_r, mid_angle)
        rot = _outward_radial_rotation(mid_angle)
        children.append(SceneText(
            x=tx, y=ty,
            content=label,
            font_size=font_size,
            fill=TEXT_DARK,
            anchor="middle",
            rotation=rot,
        ))
        if dates_label:
            ltx, lty = _polar(cx, cy, life_r, mid_angle)
            children.append(SceneText(
                x=ltx, y=lty,
                content=dates_label,
                font_size=min(life_font, font_size),
                fill=TEXT_GREY,
                anchor="middle",
                rotation=rot,
            ))
    elif show_text:
        path = _arc_text_path(cx, cy, name_r, start_angle, end_angle, lower=False)
        children.append(ScenePathText(
            path=path,
            content=label,
            font_size=font_size,
            fill=TEXT_DARK,
        ))
        if dates_label:
            life_path = _arc_text_path(cx, cy, life_r, start_angle, end_angle, lower=False)
            children.append(ScenePathText(
                path=life_path,
                content=dates_label,
                font_size=min(life_font, font_size),
                fill=TEXT_GREY,
            ))

    # Portrait/fallback medallion sized for this ring and angular lane.
    marker_position: tuple[float, float, float] | None = None
    if show_medallion and med_r > 0.5:
        mx, my = _polar(cx, cy, med_r_pos, mid_angle)
        marker_position = (mx, my, med_r + 1.25)
        children.append(SceneCircle(
            cx=mx, cy=my, r=med_r,
            fill=MEDALLION_FILL,
            stroke=MEDALLION_BORDER,
            stroke_width=0.3,
        ))
        if portrait:
            children.append(SceneImage(
                cx=mx,
                cy=my,
                r=portrait_image_r,
                data_uri=portrait,
            ))
        else:
            # Add initials text inside the medallion
            initials = _extract_initials(label)
            if initials:
                children.append(SceneText(
                    x=mx, y=my + med_r * 0.25,
                    content=initials,
                    font_size=med_r * 0.55,
                    fill=TEXT_DARK,
                    anchor="middle",
                ))

    if highlighted:
        if marker_position is None:
            marker_x, marker_y = _polar(
                cx, cy, max(inner_r, outer_r - 1.5), mid_angle
            )
            marker_radius = min(2.0, max(0.9, sweep * 0.04))
        else:
            marker_x, marker_y, marker_radius = marker_position
        children.append(SceneMarker(
            cx=marker_x,
            cy=marker_y,
            radius=marker_radius,
        ))


# ---------------------------------------------------------------------------
# Center couple placement
# ---------------------------------------------------------------------------

_LABEL_FILL = TEXT_DARK
_STATS_FILL = TEXT_GREY
_CENTER_NAME_MIN_SIZE = 5.5


def _center_name_style(content: str, radius: float) -> tuple[float, float]:
    """Return an adaptive font size and the safe center-label width.

    The label sits below the center medallions. Its available width is the
    horizontal chord of the inner white circle at that baseline, minus a
    proportional side margin. Keeping the full label and passing this width
    to the renderer prevents long couples from being clipped at the circle's
    edge while avoiding a fixed-size label that only works for short names.
    """
    baseline_offset = radius * (48.0 / 190.0)
    inner_radius = radius * 0.94
    half_chord = math.sqrt(
        max(0.0, inner_radius**2 - baseline_offset**2)
    )
    max_width = max(1.0, 2.0 * half_chord - radius * 0.12)
    target_size = radius * (23.0 / 190.0)
    natural_at_one = estimate_text_width(content, 1.0)
    if natural_at_one > 0:
        target_size = min(target_size, max_width / natural_at_one)
    return max(_CENTER_NAME_MIN_SIZE, target_size), max_width


def layout_center(
    canvas: ChartCanvas,
    *,
    left_label: str,
    right_label: str | None = None,
    left_dates: str = "",
    right_dates: str = "",
    left_portrait: str | None = None,
    right_portrait: str | None = None,
    left_fallback: str = "",
    right_fallback: str = "",
    left_highlighted: bool = False,
    right_highlighted: bool = False,
    show_highlight_markers: bool = False,
    statistics: str | None = None,
) -> SceneNode:
    """Place the center family medallion with labels, portraits and stats.

    The center zone (canvas.center_radius_mm) creates a breathing area
    like the mockup's ivory circle.  The actual medallions are ~35% of
    this zone's radius, placed at the top, with the "&" between them and
    the combined name + stats below.
    """
    cx = canvas.center_cx_mm
    cy = canvas.center_cy_mm
    r = canvas.center_radius_mm  # the full center zone (ivory circle)
    left_highlighted = left_highlighted and show_highlight_markers
    right_highlighted = right_highlighted and show_highlight_markers

    children: list = []

    if right_label is not None:
        # Exact center proportions from the 190 px mockup center circle.
        med_r = r * (52.0 / 190.0)
        offset = r * (64.0 / 190.0)
        left_cx = cx - offset
        right_cx = cx + offset
        med_cy = cy - r * (28.0 / 190.0)

        # Outer ivory circle (the breathing zone)
        children.append(SceneCircle(
            cx=cx, cy=cy, r=r,
            fill="#FAF9F5",
            stroke="#D1CFC5",
            stroke_width=0.3,
        ))

        # Inner white circle (like mockup line 386)
        children.append(SceneCircle(
            cx=cx, cy=cy, r=r * 0.94,
            fill="#FFFFFF",
            stroke="#E3DACC",
            stroke_width=0.8,
        ))

        children.append(SceneCircle(
            cx=left_cx, cy=med_cy, r=med_r,
            fill=MEDALLION_FILL,
            stroke=MEDALLION_BORDER,
            stroke_width=0.4,
        ))
        children.append(SceneCircle(
            cx=right_cx, cy=med_cy, r=med_r,
            fill=MEDALLION_FILL,
            stroke=MEDALLION_BORDER,
            stroke_width=0.4,
        ))

        if left_portrait or left_fallback:
            children.append(SceneImage(
                cx=left_cx, cy=med_cy, r=med_r * 0.92,
                data_uri=left_portrait,
                fallback_text=left_fallback,
            ))
        if right_portrait or right_fallback:
            children.append(SceneImage(
                cx=right_cx, cy=med_cy, r=med_r * 0.92,
                data_uri=right_portrait,
                fallback_text=right_fallback,
            ))

        if left_highlighted:
            children.append(SceneMarker(cx=left_cx, cy=med_cy, radius=med_r + 1.25))
        if right_highlighted:
            children.append(SceneMarker(cx=right_cx, cy=med_cy, radius=med_r + 1.25))

        # "&" symbol between the two medallions (mockup uses clay color)
        children.append(SceneText(
            x=cx, y=med_cy + med_r * 0.20,
            content="&",
            font_size=r * (28.0 / 190.0),
            fill="#D97757",
            anchor="middle",
        ))

        # Combined name below the medallions. Fit against the actual white
        # circle chord instead of using one fixed size for every couple.
        combined = f"{left_label} & {right_label}"
        name_size, name_max_width = _center_name_style(combined, r)
        children.append(SceneText(
            x=cx, y=cy + r * (48.0 / 190.0),
            content=combined,
            font_size=name_size,
            fill=_LABEL_FILL,
            anchor="middle",
            font_weight="500",
            max_width=name_max_width,
        ))

        # One life-span line per partner, aligned beneath the shared name line.
        date_y = cy + r * (72.0 / 190.0)
        date_size = r * (13.0 / 190.0)
        if left_dates:
            children.append(SceneText(
                x=left_cx, y=date_y,
                content=left_dates,
                font_size=date_size,
                fill=TEXT_GREY,
                anchor="middle",
            ))
        if right_dates:
            children.append(SceneText(
                x=right_cx, y=date_y,
                content=right_dates,
                font_size=date_size,
                fill=TEXT_GREY,
                anchor="middle",
            ))
    else:
        # Single medallion for incomplete couple
        med_r = r * (52.0 / 190.0)
        children.append(SceneCircle(
            cx=cx, cy=cy, r=r,
            fill="#FAF9F5",
            stroke="#D1CFC5",
            stroke_width=0.3,
        ))
        children.append(SceneCircle(
            cx=cx, cy=cy - r * (28.0 / 190.0), r=med_r,
            fill=MEDALLION_FILL,
            stroke=MEDALLION_BORDER,
            stroke_width=0.4,
        ))
        if left_portrait or left_fallback:
            children.append(SceneImage(
                cx=cx,
                cy=cy - r * (28.0 / 190.0),
                r=med_r * 0.92,
                data_uri=left_portrait,
                fallback_text=left_fallback,
            ))
        if left_highlighted:
            children.append(SceneMarker(
                cx=cx,
                cy=cy - r * (28.0 / 190.0),
                radius=med_r + 1.25,
            ))
        name_size, name_max_width = _center_name_style(left_label, r)
        children.append(SceneText(
            x=cx, y=cy + r * (48.0 / 190.0),
            content=left_label,
            font_size=name_size,
            fill=_LABEL_FILL,
            anchor="middle",
            font_weight="500",
            max_width=name_max_width,
        ))
        if left_dates:
            children.append(SceneText(
                x=cx, y=cy + r * (72.0 / 190.0),
                content=left_dates,
                font_size=r * (13.0 / 190.0),
                fill=TEXT_GREY,
                anchor="middle",
            ))

    if statistics:
        children.append(SceneText(
            x=cx, y=cy + r * 2 + 5,
            content=statistics,
            font_size=r * 0.22,
            fill=_STATS_FILL,
            anchor="middle",
        ))

    return SceneNode(children=tuple(children))


# ---------------------------------------------------------------------------
# Title and legend placement
# ---------------------------------------------------------------------------

def layout_titles(
    canvas: ChartCanvas,
    *,
    ancestor_generations: int,
    descendant_generations: int,
) -> SceneNode:
    """Place the ASCENDANTS and DESCENDANTS titles above and below the fan."""
    cx = canvas.center_cx_mm
    cy = canvas.center_cy_mm
    children: list = []

    if ancestor_generations > 0:
        # Title above the top arc
        title_y = cy - canvas.ancestor_outer_radius_mm - 4
        generation_word = "GÉNÉRATION" if ancestor_generations == 1 else "GÉNÉRATIONS"
        title_text = f"ASCENDANTS · {ancestor_generations} {generation_word}"
        children.append(SceneText(
            x=cx, y=title_y,
            content=title_text,
            font_size=5.0,
            fill=TEXT_GREY,
            anchor="middle",
        ))

    if descendant_generations > 0:
        # Title below the bottom arc
        title_y = cy + canvas.descendant_outer_radius_mm + 8
        generation_word = "GÉNÉRATION" if descendant_generations == 1 else "GÉNÉRATIONS"
        title_text = f"DESCENDANTS · {descendant_generations} {generation_word}"
        children.append(SceneText(
            x=cx, y=title_y,
            content=title_text,
            font_size=5.0,
            fill=TEXT_GREY,
            anchor="middle",
        ))

    return SceneNode(children=tuple(children))


def layout_legend(
    canvas: ChartCanvas,
    *,
    show_legend: bool = True,
) -> SceneNode:
    """Place the legend block in the top-left corner."""
    if not show_legend:
        return SceneNode(children=())

    x = canvas.page_width_mm * 0.03
    y = canvas.page_height_mm * 0.05

    items = (
        ("portrait disponible", MEDALLION_BORDER),
        ("initiales si absent", "#D1CFC5"),
        ("vivant masqué", HIDDEN_FILL),
    )

    children: list = [SceneLegend(x=x, y=y, items=items)]
    return SceneNode(children=tuple(children))


def layout_stats(
    canvas: ChartCanvas,
    *,
    person_count: int = 0,
    ancestor_generations: int = 0,
    descendant_generations: int = 0,
    family_id: str = "",
    child_count: int = 0,
    grandchild_count: int = 0,
) -> SceneNode:
    """Place the publication info block in the top-right corner."""
    x = canvas.page_width_mm * 0.82
    y = canvas.page_height_mm * 0.05

    children: list = []
    # Background card
    children.append(SceneRect(
        x=x - 4, y=y - 6,
        width=52.0, height=32.0,
    ))
    # Title line
    children.append(SceneText(
        x=x, y=y,
        content="MODE PUBLICATION",
        font_size=4.0,
        fill=TEXT_GREY,
        anchor="start",
    ))
    # Stats lines
    lines = []
    if person_count:
        lines.append(f"{person_count} personnes")
    if ancestor_generations:
        lines.append(f"{ancestor_generations} générations ↑")
    if descendant_generations:
        lines.append(f"{descendant_generations} générations ↓")

    for i, line in enumerate(lines):
        children.append(SceneText(
            x=x, y=y + 6 + i * 5,
            content=line,
            font_size=3.5,
            fill=TEXT_DARK,
            anchor="start",
        ))

    return SceneNode(children=tuple(children))


# ---------------------------------------------------------------------------
# Descendant branch allocation
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class DescendantBranchAllocation:
    """Angle allocation for one descendant branch."""

    start_angle: float
    sweep_angle: float
    leaf_count: int


@dataclass(frozen=True, slots=True)
class _DescendantUnionAllocation:
    """One contiguous angular block belonging to one recorded union."""

    union_index: int
    children: tuple[DescendantBranch, ...]
    start_angle: float
    sweep_angle: float


def allocate_descendant_branches(
    canvas: ChartCanvas,
    *,
    leaf_counts: list[int],
    start_angle: float,
    total_sweep: float,
    minimum_angle: float = 3.0,
) -> tuple[DescendantBranchAllocation, ...]:
    """Allocate angular sweep to descendant branches.

    Uses weighted allocation proportional to leaf counts, with a minimum
    angle per branch. Results are deterministic for the same inputs.
    """
    n = len(leaf_counts)
    if n == 0:
        return ()

    total_leaves = sum(leaf_counts)
    # Reserve minimum angle for each branch, distribute the rest proportionally
    reserved = minimum_angle * n
    remaining = total_sweep - reserved
    if remaining < 0:
        remaining = 0

    allocations: list[DescendantBranchAllocation] = []
    angle = start_angle
    for i, count in enumerate(leaf_counts):
        if total_leaves > 0 and remaining > 0:
            proportional = remaining * count / total_leaves
        else:
            proportional = 0
        sweep = minimum_angle + proportional
        allocations.append(DescendantBranchAllocation(
            start_angle=angle,
            sweep_angle=sweep,
            leaf_count=count,
        ))
        angle += sweep

    # Normalise to ensure exact total sweep
    current_total = sum(a.sweep_angle for a in allocations)
    if current_total > 0 and abs(current_total - total_sweep) > 0.001:
        factor = total_sweep / current_total
        adjusted = []
        angle = start_angle
        for a in allocations:
            adjusted_sweep = a.sweep_angle * factor
            adjusted.append(DescendantBranchAllocation(
                start_angle=angle,
                sweep_angle=adjusted_sweep,
                leaf_count=a.leaf_count,
            ))
            angle += adjusted_sweep
        return tuple(adjusted)

    return tuple(allocations)


def _allocate_publication_branches(
    child_counts: list[int],
    *,
    start_angle: float,
    total_sweep: float,
    base_angle: float = 18.0,
) -> tuple[DescendantBranchAllocation, ...]:
    """Allocate first-generation branches with the reference mockup formula.

    Every child receives a readable base sector. Only grandchildren beyond the
    first two widen the branch, preventing childless branches from collapsing
    to the tiny slivers produced by pure leaf-proportional allocation.
    """
    if not child_counts:
        return ()

    base = min(base_angle, total_sweep / len(child_counts))
    extras = [max(0, count - 2) for count in child_counts]
    extra_total = sum(extras)
    remaining = max(0.0, total_sweep - base * len(child_counts))
    if extra_total:
        widths = [base + remaining * extra / extra_total for extra in extras]
    else:
        widths = [total_sweep / len(child_counts)] * len(child_counts)

    angle = start_angle
    allocations: list[DescendantBranchAllocation] = []
    for count, width in zip(child_counts, widths):
        allocations.append(DescendantBranchAllocation(angle, width, count))
        angle += width
    return tuple(allocations)


# ---------------------------------------------------------------------------
# Descendant node placement
# ---------------------------------------------------------------------------

_DESC_MEDALLION_R_FACTOR = 0.7  # relative to center radius


def layout_descendant_node(
    canvas: ChartCanvas,
    *,
    child_label: str,
    spouse_label: str | None = None,
    additional_spouses: tuple[str, ...] = (),
    child_portrait: str | None = None,
    spouse_portrait: str | None = None,
    child_fallback: str = "",
    spouse_fallback: str = "",
    child_highlighted: bool = False,
    spouse_highlighted: bool = False,
    cx: float | None = None,
    cy: float | None = None,
    r: float | None = None,
) -> SceneNode:
    """Place a descendant with optional spouse(s) as twin medallions.

    For multiple unions, additional spouse medallions are placed
    horizontally next to the primary spouse.
    """
    _cx = cx if cx is not None else canvas.center_cx_mm
    _cy = cy if cy is not None else canvas.center_cy_mm + canvas.center_radius_mm * 2
    _r = r if r is not None else canvas.center_radius_mm * _DESC_MEDALLION_R_FACTOR

    children: list = []

    all_spouses: list[str | None] = []
    if spouse_label is not None:
        all_spouses.append(spouse_label)
    all_spouses.extend(additional_spouses)

    n_medallions = 1 + len(all_spouses)  # child + spouses
    spacing = _r * 1.2
    total_width = (n_medallions - 1) * spacing
    start_x = _cx - total_width / 2

    # Child medallion (always first, leftmost)
    child_cx = start_x
    children.append(SceneCircle(
        cx=child_cx, cy=_cy, r=_r,
        fill=MEDALLION_FILL,
        stroke=MEDALLION_BORDER,
        stroke_width=0.5,
    ))
    if child_portrait or child_fallback:
        children.append(SceneImage(
            cx=child_cx, cy=_cy, r=_r * 0.8,
            data_uri=child_portrait,
            fallback_text=child_fallback,
        ))
    if child_highlighted:
        children.append(SceneMarker(cx=child_cx, cy=_cy, radius=_r + 1.25))
    children.append(SceneText(
        x=child_cx, y=_cy + _r + 2,
        content=child_label,
        font_size=_r * 0.28,
        fill=_LABEL_FILL,
        anchor="middle",
    ))

    # Spouse medallions
    for i, sp_label in enumerate(all_spouses):
        sp_cx = start_x + (i + 1) * spacing
        children.append(SceneCircle(
            cx=sp_cx, cy=_cy, r=_r,
            fill=MEDALLION_FILL,
            stroke=MEDALLION_BORDER,
            stroke_width=0.5,
        ))
        # Only primary spouse gets portrait/fallback
        sp_data = spouse_portrait if i == 0 else None
        sp_fb = spouse_fallback if i == 0 else ""
        if sp_data or sp_fb:
            children.append(SceneImage(
                cx=sp_cx, cy=_cy, r=_r * 0.8,
                data_uri=sp_data,
                fallback_text=sp_fb,
            ))
        if spouse_highlighted and i == 0:
            children.append(SceneMarker(cx=sp_cx, cy=_cy, radius=_r + 1.25))
        children.append(SceneText(
            x=sp_cx, y=_cy + _r + 2,
            content=sp_label,
            font_size=_r * 0.28,
            fill=_LABEL_FILL,
            anchor="middle",
        ))

    return SceneNode(children=tuple(children))


# ---------------------------------------------------------------------------
# Full descendant tree placement
# ---------------------------------------------------------------------------

_DESC_START_ANGLE = 96.0  # mockup: 6° waist gap on the right
_DESC_TOTAL_SWEEP = 168.0  # descendants end at 264°, leaving 6° on the left

# Minimum useful angular slot per descendant generation. Allocation is driven
# by the most demanding visible depth rather than immediate child count, so a
# branch with few children but many deep descendants receives enough room.
_DESC_MIN_SWEEP_BY_GENERATION = {
    1: 14.0,
    2: 3.5,
    3: 1.4,
    4: 1.0,
    5: 0.8,
}

# Below this radius a circle is perceived as a dot rather than a medallion on
# large-format output. Narrow sectors degrade to text-only instead of shrinking
# every medallion in the generation to an unreadable common minimum.
_MIN_INITIALS_MEDALLION_RADIUS_MM = 3.2


def _count_leaves(branch: DescendantBranch) -> int:
    """Count the total leaf nodes in a descendant branch tree."""
    if not branch.children:
        return 1
    return sum(_count_leaves(child) for child in branch.children)


def _descendant_generation_counts(branch: DescendantBranch) -> dict[int, int]:
    """Count visible nodes by absolute generation inside one branch."""
    counts: dict[int, int] = {}

    def _visit(node: DescendantBranch) -> None:
        counts[node.generation] = counts.get(node.generation, 0) + 1
        for child in node.children:
            _visit(child)

    _visit(branch)
    return counts


def _descendant_angle_demand(branch: DescendantBranch) -> float:
    """Return the branch sweep needed by its densest visible generation."""
    demand = 0.0
    for generation, count in _descendant_generation_counts(branch).items():
        slot = _DESC_MIN_SWEEP_BY_GENERATION.get(generation, 0.8)
        demand = max(demand, count * slot)
    return max(demand, _DESC_MIN_SWEEP_BY_GENERATION.get(branch.generation, 0.8))


def _children_grouped_by_union(
    branch: DescendantBranch,
) -> tuple[tuple[DescendantBranch, ...], ...]:
    """Return descendant children grouped by their recorded union.

    New extraction results carry the grouping explicitly. The fallback keeps
    older hand-built graph fixtures usable by matching the recorded child
    handles in each ``UnionBranch`` rather than assigning every child to the
    first union.
    """
    if branch.children_by_union:
        return branch.children_by_union
    if not branch.children:
        return tuple(() for _union in branch.unions)
    if not branch.unions:
        return (branch.children,)

    remaining = list(branch.children)
    groups: list[tuple[DescendantBranch, ...]] = []
    for union in branch.unions:
        group: list[DescendantBranch] = []
        for child_handle in union.child_handles:
            match_index = next(
                (
                    index
                    for index, child in enumerate(remaining)
                    if child.person.handle == child_handle
                ),
                None,
            )
            if match_index is not None:
                group.append(remaining.pop(match_index))
        groups.append(tuple(group))

    # Do not silently drop children from legacy fixtures whose union metadata
    # is incomplete. They remain visible under the final recorded union.
    if remaining:
        if groups:
            groups[-1] = groups[-1] + tuple(remaining)
        else:
            groups.append(tuple(remaining))
    return tuple(groups)


def _descendant_group_angle_demand(
    children: tuple[DescendantBranch, ...],
) -> float:
    """Return the deepest-generation demand for one union's children."""
    counts: dict[int, int] = {}
    for child in children:
        for generation, count in _descendant_generation_counts(child).items():
            counts[generation] = counts.get(generation, 0) + count
    return max(
        (
            count * _DESC_MIN_SWEEP_BY_GENERATION.get(generation, 0.8)
            for generation, count in counts.items()
        ),
        default=0.8,
    )


def _allocate_descendant_union_groups(
    branch: DescendantBranch,
    *,
    start_angle: float,
    total_sweep: float,
) -> tuple[_DescendantUnionAllocation, ...]:
    """Allocate non-empty child groups while retaining their union identity."""
    groups = _children_grouped_by_union(branch)
    nonempty_groups = [
        (union_index, group)
        for union_index, group in enumerate(groups)
        if group
    ]
    if len(nonempty_groups) <= 1:
        if nonempty_groups:
            union_index, group = nonempty_groups[0]
        elif branch.children:
            union_index, group = -1, branch.children
        else:
            return ()
        return (
            _DescendantUnionAllocation(
                union_index,
                tuple(group),
                start_angle,
                total_sweep,
            ),
        )

    demands = [
        _descendant_group_angle_demand(group)
        for _union_index, group in nonempty_groups
    ]
    total_demand = sum(demands) or float(len(nonempty_groups))
    allocations: list[_DescendantUnionAllocation] = []
    angle = start_angle
    for group_index, ((union_index, group), demand) in enumerate(
        zip(nonempty_groups, demands)
    ):
        if group_index == len(nonempty_groups) - 1:
            group_sweep = start_angle + total_sweep - angle
        else:
            group_sweep = total_sweep * demand / total_demand
        allocations.append(
            _DescendantUnionAllocation(
                union_index,
                tuple(group),
                angle,
                group_sweep,
            )
        )
        angle += group_sweep
    return tuple(allocations)


def _allocate_descendant_children(
    branch: DescendantBranch,
    *,
    start_angle: float,
    total_sweep: float,
) -> tuple[DescendantBranchAllocation, ...]:
    """Allocate children in contiguous angular blocks per union.

    Each union receives a block sized from the demand of its own children;
    children from different spouses therefore cannot interleave in the same
    descendant sector.
    """
    allocations: list[DescendantBranchAllocation] = []
    for group in _allocate_descendant_union_groups(
        branch,
        start_angle=start_angle,
        total_sweep=total_sweep,
    ):
        allocations.extend(
            _allocate_descendant_branches_by_demand(
                group.children,
                start_angle=group.start_angle,
                total_sweep=group.sweep_angle,
            )
        )
    return tuple(allocations)


def _allocate_descendant_branches_by_demand(
    branches: tuple[DescendantBranch, ...],
    *,
    start_angle: float,
    total_sweep: float,
) -> tuple[DescendantBranchAllocation, ...]:
    """Allocate siblings in proportion to their deepest-generation demand."""
    if not branches:
        return ()
    demands = [_descendant_angle_demand(branch) for branch in branches]
    total_demand = sum(demands)
    if total_demand <= 0:
        demands = [1.0] * len(branches)
        total_demand = float(len(branches))

    allocations: list[DescendantBranchAllocation] = []
    angle = start_angle
    for index, (branch, demand) in enumerate(zip(branches, demands)):
        if index == len(branches) - 1:
            sweep = start_angle + total_sweep - angle
        else:
            sweep = total_sweep * demand / total_demand
        allocations.append(DescendantBranchAllocation(
            start_angle=angle,
            sweep_angle=sweep,
            leaf_count=_count_leaves(branch),
        ))
        angle += sweep
    return tuple(allocations)


def _max_desc_depth(branch: DescendantBranch) -> int:
    """Return the maximum visible descendant depth for one branch."""
    if not branch.children:
        return 1
    return 1 + max(_max_desc_depth(child) for child in branch.children)


def _descendant_label(branch: DescendantBranch, name_lookup) -> str:
    """Get a short label for a descendant branch via the name lookup callable."""
    return name_lookup(branch.person.handle) if branch.person else ""


def _spouse_label(union, name_lookup) -> str | None:
    """Get a short label for a union's spouse via the name lookup callable."""
    if not union.spouse_handle:
        return None
    return name_lookup(union.spouse_handle)


def _descendant_ring_bounds(
    inner_radius: float,
    outer_radius: float,
    generation_count: int,
    depth: int,
) -> tuple[float, float]:
    """Return ring-local descendant bounds for one supported depth."""
    if generation_count < 1 or depth < 1 or depth > generation_count:
        raise ValueError("descendant depth must be inside the configured generation range")
    total_depth = outer_radius - inner_radius
    if generation_count == 1:
        widths = [total_depth]
    elif generation_count == 2:
        # Freeze the exact two-ring reference geometry.
        exact_inner = (202 / 600, 355 / 600)
        exact_outer = (350 / 600, 598 / 600)
        return (
            outer_radius * exact_inner[depth - 1],
            outer_radius * exact_outer[depth - 1],
        )
    else:
        weights = [1.0 + 0.35 * index for index in range(generation_count)]
        total_weight = sum(weights)
        widths = [total_depth * weight / total_weight for weight in weights]
    ring_inner = inner_radius + sum(widths[: depth - 1])
    return ring_inner, ring_inner + widths[depth - 1] - _RING_GAP_MM


def layout_descendants(
    canvas: ChartCanvas,
    branches: tuple[DescendantBranch, ...],
    *,
    name_lookup,
    dates_lookup=None,
    shortener=None,
    portrait_lookup=None,
    highlight_lookup=None,
    show_highlight_markers: bool = False,
) -> SceneNode:
    """Place all descendant medallions in the lower half-circle.

    Generates:
    - Colored annular sectors for each child branch
    - Sub-sectors for grandchildren
    - Curved text labels for children (shortened via *shortener*)
    - A second curved arc with the spouse name prefixed by ``×``
    - Medallions at the midpoint of first-generation sectors only
    - Straight text for grandchildren

    Highlight markers are opt-in so publication views do not expose tag
    annotations unless explicitly requested.
    """
    if not branches:
        return SceneNode(children=())

    # Allocate every first-generation branch from the densest visible depth,
    # not merely its immediate child count. This prevents deep lineages from
    # collapsing into sub-degree outer sectors while sparse branches stay wide.
    allocations = _allocate_descendant_branches_by_demand(
        branches,
        start_angle=_DESC_START_ANGLE,
        total_sweep=_DESC_TOTAL_SWEEP,
    )

    all_children: list = []
    measure_only = True
    name_size_candidates: dict[int, list[float]] = {}
    generation_name_sizes: dict[int, float] = {}
    inner_r = canvas.descendant_inner_radius_mm
    outer_r = canvas.descendant_outer_radius_mm
    max_gen = max(_max_desc_depth(b) for b in branches) if branches else 1
    total_depth = outer_r - inner_r
    if max_gen <= 1:
        ring_widths = [total_depth]
    elif max_gen == 2:
        # Match the mockup: children ring narrower, grandchildren ring wider.
        ring_widths = [total_depth * 0.38, total_depth * 0.62]
    else:
        # Grow outer descendant rings progressively when deeper trees appear.
        weights = [1.0 + 0.35 * i for i in range(max_gen)]
        total_w = sum(weights)
        ring_widths = [total_depth * w / total_w for w in weights]

    cx = canvas.center_cx_mm
    cy = canvas.center_cy_mm

    def _short(label: str, depth: int) -> str:
        if shortener is None or not label:
            return label
        try:
            return shortener(label, depth)
        except Exception:
            return label

    def _portrait(handle: str | None) -> str | None:
        if measure_only or portrait_lookup is None or not handle:
            return None
        try:
            return portrait_lookup(handle)
        except Exception:
            return None

    def _highlight(handle: str | None) -> bool:
        if (
            measure_only
            or not show_highlight_markers
            or highlight_lookup is None
            or not handle
        ):
            return False
        try:
            return bool(highlight_lookup(handle))
        except Exception:
            return False

    def _fit_generation_name(
        content: str,
        depth: int,
        *,
        target_size: float,
        minimum_size: float,
        max_width: float,
        allow_ellipsis: bool = True,
    ) -> tuple[str, float, float]:
        """Fit a name while keeping one measured size for its generation."""
        common_size = generation_name_sizes.get(depth)
        if not measure_only and common_size is not None:
            fitted, _ignored_size, width_limit = _fit_text_to_width(
                content,
                target_size=common_size,
                minimum_size=common_size,
                max_width=max_width,
                allow_ellipsis=allow_ellipsis,
            )
            return fitted, common_size, width_limit

        fitted, fitted_size, width_limit = _fit_text_to_width(
            content,
            target_size=target_size,
            minimum_size=minimum_size,
            max_width=max_width,
            allow_ellipsis=allow_ellipsis,
        )
        if measure_only:
            if content:
                name_size_candidates.setdefault(depth, []).append(fitted_size)
            return fitted, fitted_size, width_limit
        return fitted, fitted_size, width_limit

    def _fit_generation_couple(
        child_label: str,
        spouse_label: str,
        depth: int,
        *,
        target_size: float,
        minimum_size: float,
        max_width: float,
    ) -> tuple[str, float, float]:
        """Fit a compact couple label at the common generation size."""
        common_size = generation_name_sizes.get(depth)
        if not measure_only and common_size is not None:
            fitted, _ignored_size, width_limit = _fit_couple_to_width(
                child_label,
                spouse_label,
                target_size=common_size,
                minimum_size=common_size,
                max_width=max_width,
            )
            return fitted, common_size, width_limit

        fitted, fitted_size, width_limit = _fit_couple_to_width(
            child_label,
            spouse_label,
            target_size=target_size,
            minimum_size=minimum_size,
            max_width=max_width,
        )
        if measure_only:
            if child_label or spouse_label:
                name_size_candidates.setdefault(depth, []).append(fitted_size)
            return fitted, fitted_size, width_limit
        return fitted, fitted_size, width_limit

    def _target_medallion_radius(depth: int, ring_depth: float) -> float:
        """Return a readable target; individual narrow sectors may omit it."""
        ideal = {1: 8.2, 2: 5.4, 3: 4.0, 4: 3.4, 5: 3.2}.get(depth, 3.2)
        reserved_text_depth = (
            min(36.0, ring_depth * 0.58)
            if depth == 1
            else min(max(28.0, ring_depth * 0.45), ring_depth * 0.58)
        )
        radial_cap = max(
            0.0,
            (ring_depth - 1.6 - reserved_text_depth) / 2.0,
        )
        return min(ideal, radial_cap)

    def _emit_medallion(
        x: float,
        y: float,
        radius: float,
        label: str,
        portrait: str | None,
        highlighted: bool = False,
    ) -> None:
        all_children.append(SceneCircle(
            cx=x,
            cy=y,
            r=radius * (1.1 if portrait else 1.0),
            fill=MEDALLION_FILL,
            stroke=MEDALLION_BORDER,
            stroke_width=0.3,
        ))
        if highlighted:
            all_children.append(SceneMarker(
                cx=x,
                cy=y,
                radius=radius + 1.25,
            ))
        if portrait:
            all_children.append(SceneImage(
                cx=x,
                cy=y,
                r=radius,
                data_uri=portrait,
            ))
            return
        initials = _extract_initials(label) if label else ""
        if initials:
            all_children.append(SceneText(
                x=x,
                y=y + radius * 0.25,
                content=initials,
                font_size=radius * 0.55,
                fill=TEXT_DARK,
                anchor="middle",
            ))

    def _place_branch(
        branch: DescendantBranch,
        alloc_start: float,
        alloc_sweep: float,
        depth: int,
        branch_index: int,
    ) -> None:
        """Recursively place a branch and its children."""
        mid_angle = alloc_start + alloc_sweep / 2.0

        if max_gen >= 3:
            gen_inner, gen_outer = _descendant_ring_bounds(
                inner_r, outer_r, max_gen, depth
            )
            ring_width = gen_outer - gen_inner
        elif max_gen == 2 and depth <= 2:
            exact_inner_ratios = (202 / 600, 355 / 600)
            exact_outer_ratios = (350 / 600, 598 / 600)
            gen_inner = outer_r * exact_inner_ratios[depth - 1]
            gen_outer = outer_r * exact_outer_ratios[depth - 1]
            ring_width = gen_outer - gen_inner
        else:
            gen_inner = inner_r + sum(ring_widths[: depth - 1])
            ring_width = ring_widths[min(depth - 1, len(ring_widths) - 1)]
            gen_outer = gen_inner + ring_width - _RING_GAP_MM

        # Emit sector for this branch
        fill = descendant_fill(branch_index)
        all_children.append(SceneSector(
            inner_radius=gen_inner,
            outer_radius=gen_outer,
            start_angle=alloc_start,
            sweep_angle=alloc_sweep,
            fill=fill,
            stroke=SECTOR_STROKE,
            stroke_width=SECTOR_STROKE_WIDTH,
            cx=cx,
            cy=cy,
        ))

        raw_label = _descendant_label(branch, name_lookup)
        child_label = _short(raw_label, depth)

        spouse_entries: list[tuple[str, str, str]] = []
        if depth == 1 or (depth < max_gen and max_gen > 1):
            for union in branch.unions:
                if union.spouse_handle:
                    sp_raw = _spouse_label(union, name_lookup)
                    if sp_raw:
                        spouse_entries.append(
                            (
                                union.spouse_handle,
                                sp_raw,
                                _short(sp_raw, depth),
                            )
                        )

        spouse_handle = spouse_entries[0][0] if spouse_entries else None
        spouse_medallion_label = spouse_entries[0][1] if spouse_entries else None
        spouse_display_name = " / ".join(
            entry[2] for entry in spouse_entries if entry[2]
        )

        if raw_label == "Personne privée" and spouse_medallion_label == "Personne privée":
            child_label = "Personnes privées"
            spouse_display_name = ""

        # Place one portrait medallion or a tangent couple pair when the local
        # sector can sustain a readable circle. A narrow sector falls back to
        # text-only without shrinking every other medallion in its generation.
        # The requested default keeps the descendant GEN1 medallions as the
        # visual entry points, but removes every medallion from GEN2 onward.
        # Text and couple labels remain available in those rings.
        show_medallion = depth == 1
        adaptive_single_generation = max_gen == 1
        adaptive_dense = max_gen >= 3
        if show_medallion and adaptive_single_generation:
            has_spouse = bool(spouse_handle and spouse_medallion_label)
            med_capacity = _maximum_medallion_radius(
                inner_radius=gen_inner,
                outer_radius=gen_outer,
                sweep_angle=alloc_sweep,
                occupants=2 if has_spouse else 1,
                edge="outer",
                margin=0.8,
            )
            # Reserve the portrait border as well as the enlarged image radius.
            # The larger portrait remains in the outer crown, where it no
            # longer competes with the text lanes.
            med_visual_target = outer_r * _DESCENDANT_MEDALLION_TARGET_RATIO * 1.1
            med_visual_r = min(med_capacity, med_visual_target)
            med_border_r = (
                med_visual_r / 1.1
                if med_visual_r / 1.1 >= _MIN_INITIALS_MEDALLION_RADIUS_MM
                else 0.0
            )
            pair_offset = med_visual_r * 1.075 if has_spouse else 0.0
            if med_border_r > 0:
                target_center_radius = max(
                    0.0,
                    gen_outer - 0.8 - med_visual_r,
                )
                med_text_inner = max(
                    gen_inner,
                    target_center_radius - med_visual_r - 6.0,
                )
                med_r_pos = (
                    math.sqrt(max(0.0, target_center_radius**2 - pair_offset**2))
                    if has_spouse
                    else target_center_radius
                )
            else:
                med_text_inner = gen_outer
                med_r_pos = gen_outer
        elif show_medallion and adaptive_dense:
            has_spouse = bool(spouse_handle and spouse_medallion_label)
            med_capacity = _maximum_medallion_radius(
                inner_radius=gen_inner,
                outer_radius=gen_outer,
                sweep_angle=alloc_sweep,
                occupants=2 if has_spouse else 1,
                edge="outer",
                margin=0.8,
            )
            med_target = _target_medallion_radius(depth, gen_outer - gen_inner)
            if min(med_capacity, med_target) >= _MIN_INITIALS_MEDALLION_RADIUS_MM:
                med_border_r = min(med_capacity, med_target)
            else:
                med_border_r = 0.0
            pair_offset = med_border_r * 1.075
            if med_border_r > 0:
                target_center_radius = gen_outer - 0.8 - med_border_r
                med_text_inner = target_center_radius - med_border_r
                med_r_pos = (
                    math.sqrt(max(0.0, target_center_radius**2 - pair_offset**2))
                    if has_spouse
                    else target_center_radius
                )
            else:
                med_text_inner = gen_outer
                med_r_pos = gen_outer
        elif show_medallion:
            med_border_r = outer_r * ((20 / 600) if depth == 1 else (14 / 600))
            med_r_pos = outer_r * ((245 / 600) if depth == 1 else (397 / 600))
            pair_offset = outer_r * (20 / 600)
            med_text_inner = med_r_pos - med_border_r
        else:
            med_border_r = 0.0
            med_r_pos = gen_outer
            pair_offset = 0.0
            # Without a GEN2+ medallion, let the text use the complete ring.
            med_text_inner = gen_outer

        if med_border_r > 0.5:
            mx, my = _polar(cx, cy, med_r_pos, mid_angle)
            child_portrait_data = _portrait(
                branch.person.handle if branch.person else None
            )
            if spouse_handle and spouse_medallion_label:
                angle_rad = math.radians(mid_angle)
                tangent_x = math.cos(angle_rad)
                tangent_y = math.sin(angle_rad)
                spouse_portrait_data = _portrait(spouse_handle)
                child_radius = (
                    med_border_r / 1.1
                    if adaptive_dense and child_portrait_data
                    else med_border_r
                )
                spouse_radius = (
                    med_border_r / 1.1
                    if adaptive_dense and spouse_portrait_data
                    else med_border_r
                )
                _emit_medallion(
                    mx - tangent_x * pair_offset,
                    my - tangent_y * pair_offset,
                    child_radius,
                    child_label or raw_label,
                    child_portrait_data,
                    _highlight(branch.person.handle),
                )
                _emit_medallion(
                    mx + tangent_x * pair_offset,
                    my + tangent_y * pair_offset,
                    spouse_radius,
                    spouse_medallion_label,
                    spouse_portrait_data,
                    _highlight(spouse_handle),
                )
            else:
                child_radius = (
                    med_border_r / 1.1
                    if adaptive_dense and child_portrait_data
                    else med_border_r
                )
                _emit_medallion(
                    mx,
                    my,
                    child_radius,
                    child_label or raw_label,
                    child_portrait_data,
                    _highlight(branch.person.handle),
                )
        else:
            # Later-generation people are text-only by design. When highlight
            # markers are enabled, keep their citation signal visible with a
            # small diamond in the same sector instead of dropping it.
            marker_radius = min(2.0, max(1.1, ring_width * 0.08))
            marker_distance = max(
                gen_inner + marker_radius + 1.0,
                gen_outer - marker_radius - 1.0,
            )
            highlighted_handles = []
            if _highlight(branch.person.handle if branch.person else None):
                highlighted_handles.append(mid_angle)
            if _highlight(spouse_handle):
                highlighted_handles.append(mid_angle + min(2.0, alloc_sweep * 0.12))
            for marker_angle in highlighted_handles:
                marker_x, marker_y = _polar(
                    cx, cy, marker_distance, marker_angle
                )
                all_children.append(SceneMarker(
                    cx=marker_x,
                    cy=marker_y,
                    radius=marker_radius,
                ))

        # Labels use ring-local capacity in dense reports. The standard two-ring
        # publication geometry remains byte-for-byte compatible below.
        if child_label and adaptive_single_generation:
            child_dates = (
                dates_lookup(branch.person.handle)
                if dates_lookup is not None and branch.person
                else ""
            )
            spouse_date_parts: list[str] = []
            if dates_lookup is not None:
                for handle, _spouse_raw, _spouse_short in spouse_entries:
                    date_label = dates_lookup(handle)
                    if date_label:
                        spouse_date_parts.append(date_label)
            spouse_dates = " / ".join(spouse_date_parts)
            lines = [
                (child_label, True, TEXT_DARK),
                (child_dates, False, TEXT_GREY),
                (
                    f"× {spouse_display_name}" if spouse_display_name else "",
                    True,
                    TEXT_DARK,
                ),
                (
                    spouse_dates if spouse_display_name else "",
                    False,
                    TEXT_GREY,
                ),
            ]
            lines = [line for line in lines if line[0]]
            # The medallion occupies the outer crown; spread the identity
            # rails through the remaining radial depth instead of bunching all
            # four lines beside the center. Width is still solved per sector.
            text_start = gen_inner + 4.0
            text_end = max(text_start, med_text_inner - 2.0)
            radial_span = max(0.0, text_end - text_start)
            for line_index, (content, is_name, fill_color) in enumerate(lines):
                line_r = text_start + radial_span * (line_index + 0.5) / len(lines)
                angular_width = max(
                    0.0,
                    line_r * math.radians(max(alloc_sweep - 1.0, 0.0)) - 2.0,
                )
                if is_name:
                    fitted, fitted_size, width_limit = _fit_generation_name(
                        content,
                        depth,
                        target_size=outer_r * (12 / 600),
                        minimum_size=4.0,
                        max_width=angular_width,
                    )
                else:
                    fitted, fitted_size, width_limit = _fit_text_to_width(
                        content,
                        target_size=outer_r * (9.5 / 600),
                        minimum_size=2.8,
                        max_width=angular_width,
                    )
                if not fitted:
                    continue
                all_children.append(ScenePathText(
                    path=_arc_text_path(
                        cx,
                        cy,
                        line_r,
                        alloc_start,
                        alloc_start + alloc_sweep,
                        lower=True,
                    ),
                    content=fitted,
                    font_size=fitted_size,
                    fill=fill_color,
                    max_width=width_limit,
                ))
        elif child_label and adaptive_dense:
            child_dates = (
                dates_lookup(branch.person.handle)
                if dates_lookup is not None and branch.person
                else ""
            )
            if depth == 1:
                lines = [
                    (child_label, True, TEXT_DARK),
                    (child_dates, False, TEXT_GREY),
                ]
                for spouse_handle, _spouse_raw, spouse_short in spouse_entries:
                    lines.append((f"× {spouse_short}", True, TEXT_DARK))
                    spouse_dates = (
                        dates_lookup(spouse_handle)
                        if dates_lookup is not None
                        else ""
                    )
                    if spouse_dates:
                        lines.append((spouse_dates, False, TEXT_GREY))
                lines = [line for line in lines if line[0]]
                text_start = gen_inner + 2.0
                text_end = med_text_inner - 2.0
                radial_span = max(0.0, text_end - text_start)
                if len(lines) == 1:
                    first_line_offset = radial_span / 2.0
                    line_gap = 0.0
                else:
                    maximum_line_gap = radial_span / (len(lines) - 1)
                    preferred_line_gap = max(
                        _DESCENDANT_FIRST_GEN_LINE_GAP_MM,
                        radial_span / (len(lines) + 1),
                    )
                    line_gap = min(preferred_line_gap, maximum_line_gap)
                    first_line_offset = (
                        radial_span - line_gap * (len(lines) - 1)
                    ) / 2.0
                for line_index, (content, is_name, fill_color) in enumerate(lines):
                    line_r = text_start + first_line_offset + line_gap * line_index
                    angular_width = max(
                        0.0,
                        line_r * math.radians(max(alloc_sweep - 1.0, 0.0)) - 2.0,
                    )
                    if is_name:
                        fitted, fitted_size, width_limit = _fit_generation_name(
                            content,
                            depth,
                            target_size=4.5,
                            minimum_size=3.2,
                            max_width=angular_width,
                        )
                    else:
                        fitted, fitted_size, width_limit = _fit_text_to_width(
                            content,
                            target_size=3.4,
                            minimum_size=2.5,
                            max_width=angular_width,
                        )
                    if not fitted:
                        continue
                    all_children.append(ScenePathText(
                        path=_arc_text_path(
                            cx,
                            cy,
                            line_r,
                            alloc_start,
                            alloc_start + alloc_sweep,
                            lower=True,
                        ),
                        content=fitted,
                        font_size=fitted_size,
                        fill=fill_color,
                        max_width=width_limit,
                    ))
            else:
                text_start = gen_inner + 2.0
                text_end = med_text_inner - 2.0
                text_width = max(0.0, text_end - text_start)
                text_r = (text_start + text_end) / 2.0
                name_target = {2: 4.2, 3: 3.6, 4: 3.2, 5: 3.0}.get(depth, 3.0)
                name_minimum = 3.2 if depth == 2 else 2.8
                base_x, base_y = _polar(cx, cy, text_r, mid_angle)
                rotation = _outward_radial_rotation(mid_angle)
                angular_capacity = max(
                    0.0,
                    text_r * math.radians(max(alloc_sweep - 0.25, 0.0)) - 1.0,
                )

                if spouse_display_name:
                    # Medium sectors use two parallel radial rails. Narrower
                    # sectors preserve both identities and the union marker in
                    # one compact rail; dates are sacrificed before either name.
                    parallel_capacity = name_target * 2.35
                    if angular_capacity >= parallel_capacity:
                        child_fit, child_size, child_width = _fit_generation_name(
                            child_label,
                            depth,
                            target_size=name_target,
                            minimum_size=name_minimum,
                            max_width=text_width,
                        )
                        spouse_fit, spouse_size, spouse_width = _fit_generation_name(
                            f"× {spouse_display_name}",
                            depth,
                            target_size=name_target,
                            minimum_size=name_minimum,
                            max_width=text_width,
                        )
                        lane_offset = max(child_size, spouse_size) * 0.68
                        for content, size, width, offset, color in (
                            (child_fit, child_size, child_width, -lane_offset, TEXT_DARK),
                            (spouse_fit, spouse_size, spouse_width, lane_offset, TEXT_DARK),
                        ):
                            if not content:
                                continue
                            tx, ty = _tangent_offset(
                                base_x, base_y, mid_angle, offset
                            )
                            all_children.append(SceneText(
                                x=tx,
                                y=ty,
                                content=content,
                                font_size=size,
                                fill=color,
                                anchor="middle",
                                rotation=rotation,
                                max_width=width,
                            ))
                    else:
                        couple_fit, couple_size, couple_width = _fit_generation_couple(
                            child_label,
                            spouse_display_name,
                            depth,
                            target_size=name_target,
                            minimum_size=name_minimum,
                            max_width=text_width,
                        )
                        if couple_fit:
                            all_children.append(SceneText(
                                x=base_x,
                                y=base_y,
                                content=couple_fit,
                                font_size=couple_size,
                                fill=TEXT_DARK,
                                anchor="middle",
                                rotation=rotation,
                                max_width=couple_width,
                            ))
                else:
                    fitted_name, name_size, name_width = _fit_generation_name(
                        child_label,
                        depth,
                        target_size=name_target,
                        minimum_size=name_minimum,
                        max_width=text_width,
                    )
                    date_target = min(3.0, name_size * 0.84)
                    date_minimum = min(2.4, date_target)
                    date_fit, date_size, date_width = _fit_text_to_width(
                        child_dates,
                        target_size=date_target,
                        minimum_size=date_minimum,
                        max_width=text_width,
                    )
                    show_date_lane = bool(
                        date_fit
                        and angular_capacity >= (name_size + date_size) * 1.18
                    )
                    lane_offset = max(name_size, date_size) * 0.58 if show_date_lane else 0.0
                    if fitted_name:
                        name_x, name_y = _tangent_offset(
                            base_x, base_y, mid_angle, -lane_offset
                        )
                        all_children.append(SceneText(
                            x=name_x,
                            y=name_y,
                            content=fitted_name,
                            font_size=name_size,
                            fill=TEXT_DARK,
                            anchor="middle",
                            rotation=rotation,
                            max_width=name_width,
                        ))
                    if show_date_lane:
                        date_x, date_y = _tangent_offset(
                            base_x, base_y, mid_angle, lane_offset
                        )
                        all_children.append(SceneText(
                            x=date_x,
                            y=date_y,
                            content=date_fit,
                            font_size=min(date_size, name_size),
                            fill=TEXT_GREY,
                            anchor="middle",
                            rotation=rotation,
                            max_width=date_width,
                        ))
        elif child_label:
            if depth == 1:
                label_r = outer_r * (278 / 600)
                font_size = outer_r * (12 / 600)
                all_children.append(ScenePathText(
                    path=_arc_text_path(
                        cx, cy, label_r,
                        alloc_start, alloc_start + alloc_sweep,
                        lower=True,
                    ),
                    content=child_label,
                    font_size=font_size,
                    fill=TEXT_DARK,
                ))
                child_dates = (
                    dates_lookup(branch.person.handle)
                    if dates_lookup is not None and branch.person
                    else ""
                )
                if child_dates:
                    all_children.append(ScenePathText(
                        path=_arc_text_path(
                            cx, cy, outer_r * (297 / 600),
                            alloc_start, alloc_start + alloc_sweep,
                            lower=True,
                        ),
                        content=child_dates,
                        font_size=outer_r * (9.5 / 600),
                        fill=TEXT_GREY,
                    ))
                if spouse_display_name:
                    all_children.append(ScenePathText(
                        path=_arc_text_path(
                            cx, cy, outer_r * (317 / 600),
                            alloc_start, alloc_start + alloc_sweep,
                            lower=True,
                        ),
                        content=f"× {spouse_display_name}",
                        font_size=font_size,
                        fill=TEXT_DARK,
                    ))
                    spouse_date_parts: list[str] = []
                    if dates_lookup is not None:
                        for handle, _raw, _short_name in spouse_entries:
                            date_label = dates_lookup(handle)
                            if date_label:
                                spouse_date_parts.append(date_label)
                    spouse_dates = " / ".join(spouse_date_parts)
                    if spouse_dates:
                        all_children.append(ScenePathText(
                            path=_arc_text_path(
                                cx, cy, outer_r * (337 / 600),
                                alloc_start, alloc_start + alloc_sweep,
                                lower=True,
                            ),
                            content=spouse_dates,
                            font_size=outer_r * (9.5 / 600),
                            fill=TEXT_GREY,
                        ))
            else:
                text_r = outer_r * (482 / 600)
                tx, ty = _polar(cx, cy, text_r, mid_angle)
                rot = _outward_radial_rotation(mid_angle)
                all_children.append(SceneText(
                    x=tx, y=ty,
                    content=child_label,
                    font_size=outer_r * (10.5 / 600),
                    fill=TEXT_DARK,
                    anchor="middle",
                    rotation=rot,
                ))
                if dates_lookup is not None and branch.person:
                    dates_label = dates_lookup(branch.person.handle)
                    if dates_label:
                        dx, dy = _polar(cx, cy, outer_r * (554 / 600), mid_angle)
                        all_children.append(SceneText(
                            x=dx, y=dy,
                            content=dates_label,
                            font_size=outer_r * (8.5 / 600),
                            fill=TEXT_GREY,
                            anchor="middle",
                            rotation=rot,
                        ))

        # Place children within the allocated sweep. Reuse the same deep-demand
        # allocator as the capacity pass so geometry and rendering stay aligned.
        if branch.children:
            union_allocations = _allocate_descendant_union_groups(
                branch,
                start_angle=alloc_start,
                total_sweep=alloc_sweep,
            )
            for union_allocation in union_allocations:
                child_allocs = _allocate_descendant_branches_by_demand(
                    union_allocation.children,
                    start_angle=union_allocation.start_angle,
                    total_sweep=union_allocation.sweep_angle,
                )
                for child, child_alloc in zip(
                    union_allocation.children,
                    child_allocs,
                ):
                    _place_branch(
                        child,
                        child_alloc.start_angle,
                        child_alloc.sweep_angle,
                        depth + 1,
                        branch_index,
                    )

            if depth == 1 and len(union_allocations) > 1:
                label_inner, label_outer = _descendant_ring_bounds(
                    inner_r,
                    outer_r,
                    max_gen,
                    depth + 1,
                )
                label_radius = label_inner + min(
                    8.0,
                    max(3.0, (label_outer - label_inner) * 0.18),
                )
                for union_allocation in union_allocations:
                    union_index = union_allocation.union_index
                    if not 0 <= union_index < len(branch.unions):
                        continue
                    union = branch.unions[union_index]
                    label = union.family_gramps_id
                    if not label:
                        spouse_label = _spouse_label(union, name_lookup)
                        label = _short(spouse_label or "", depth + 1)
                    if not label:
                        continue
                    label_width = max(
                        0.0,
                        label_radius
                        * math.radians(
                            max(union_allocation.sweep_angle - 1.0, 0.0)
                        )
                        - 1.0,
                    )
                    fitted, fitted_size, width_limit = _fit_text_to_width(
                        label,
                        target_size=3.2,
                        minimum_size=2.2,
                        max_width=label_width,
                        allow_ellipsis=False,
                    )
                    if not fitted:
                        continue
                    label_angle = (
                        union_allocation.start_angle
                        + union_allocation.sweep_angle / 2.0
                    )
                    label_x, label_y = _polar(
                        cx,
                        cy,
                        label_radius,
                        label_angle,
                    )
                    all_children.append(SceneText(
                        x=label_x,
                        y=label_y,
                        content=fitted,
                        font_size=fitted_size,
                        fill=TEXT_DARK,
                        anchor="middle",
                        font_weight="bold",
                        rotation=_outward_radial_rotation(label_angle),
                        max_width=width_limit,
                    ))

    # Measure every name once so the smallest fitting size becomes the
    # generation-wide contract. The second pass then renders all names in that
    # generation with the same font size; the renderer may still apply the
    # physical width constraint without changing the hierarchy.
    for bi, (branch, alloc) in enumerate(zip(branches, allocations)):
        _place_branch(branch, alloc.start_angle, alloc.sweep_angle, 1, bi)
    generation_name_sizes = {
        depth: min(sizes)
        for depth, sizes in name_size_candidates.items()
        if sizes
    }
    measure_only = False
    all_children = []
    for bi, (branch, alloc) in enumerate(zip(branches, allocations)):
        _place_branch(branch, alloc.start_angle, alloc.sweep_angle, 1, bi)

    return SceneNode(children=tuple(all_children))